import { fileURLToPath } from 'node:url'
import process from 'node:process'

import { createHmrSupervisor } from './lib/runner.ts'

/**
 * Options for running a Node.js entry module with HMR supervision.
 */
export interface RunOptions {
  /**
   * Configures the parent-owned EventSource server used to coordinate browser HMR, or disables it
   * with `false`. Enabled with default options when omitted or set to `true`.
   */
  browserHmrChannel?: boolean | BrowserHmrChannelOptions
  /** Working directory used to resolve the entry path and relative watch options. (`process.cwd()`) */
  cwd?: string
  /** Arguments passed to the entry module after the entry path. */
  entryArgs?: readonly string[]
  /** Complete environment for the child process. (`process.env`) */
  env?: NodeJS.ProcessEnv
  /** Node.js arguments passed before the entry path. */
  nodeArgs?: readonly string[]
  /** File watching options for the supervised process. */
  watch?: NodeHmrWatchOptions
}

/**
 * Browser HMR event stream options hosted by the parent process.
 */
export interface BrowserHmrChannelOptions {
  /** Hostname for the browser HMR event server. (`'127.0.0.1'`) */
  host?: string
  /** Port for the browser HMR event server. Uses an available ephemeral port when omitted. */
  port?: number
  /** URL pathname for the browser HMR event stream. (`'/hmr'`) */
  pathname?: string
}

/**
 * File watching options for a Node HMR runner.
 */
export interface NodeHmrWatchOptions {
  /**
   * Ignore matching glob patterns or file paths. Relative values are resolved
   * from the runner's `cwd`.
   */
  ignore?: readonly string[]
  /**
   * Use polling instead of native filesystem events. Defaults to `true` on
   * Windows and `false` elsewhere.
   */
  poll?: boolean
  /**
   * Polling interval in milliseconds when `poll` is enabled. Defaults to `100`.
   */
  pollInterval?: number
}

/**
 * Handle returned by {@link run} for controlling the supervised process.
 */
export interface NodeHmrRunner {
  /**
   * Stops the runner and waits for the child process to exit.
   *
   * @returns A promise that resolves once the runner has stopped.
   */
  close(): Promise<void>
  /**
   * Current server generation, incremented after every accepted hot update or process restart.
   */
  readonly generation: number
  /**
   * Waits until the latest update or restart has settled and the current child process is ready.
   *
   * If the app uses `emitServerReady()`, restart readiness also waits for that signal.
   *
   * @returns A promise that resolves when the latest requested generation is ready.
   */
  ready(): Promise<void>
}

type HmrReadyFetchRetryContext = {
  /** Child process lifecycle generation that handled the fetch attempt. */
  generation: number
  /** Request passed to the wrapped fetch handler. */
  request: Request
} & (
  | {
      /** Error thrown by the wrapped fetch handler. */
      error: unknown
      /** Response is absent when the wrapped fetch handler throws. */
      response?: never
    }
  | {
      /** Error is absent when the wrapped fetch handler returns a response. */
      error?: never
      /** Response returned by the wrapped fetch handler. */
      response: Response
    }
)

/**
 * Options for {@link createHmrReadyFetch}.
 */
export interface HmrReadyFetchOptions {
  /**
   * Determines whether a response or thrown error should be retried if the
   * runner moves to a new generation while the request is in flight. Defaults
   * to retrying `GET` and `HEAD` requests when the fetch throws or returns
   * `502`, `503`, or `504`.
   */
  shouldRetry?: (context: HmrReadyFetchRetryContext) => boolean | Promise<boolean>
}

/**
 * Wraps a fetch handler so requests wait for the current HMR generation to be ready.
 *
 * If the wrapped fetch handler returns a retryable response or throws a retryable error, the
 * request is attempted again only when the runner moved to a new generation while the request was
 * in flight.
 *
 * @param runner HMR runner that controls server readiness.
 * @param fetch Fetch handler to call once the runner is ready.
 * @param options Retry behavior for responses and thrown errors.
 * @returns A fetch handler that waits for HMR readiness before forwarding requests.
 */
export function createHmrReadyFetch(
  runner: NodeHmrRunner,
  fetch: (request: Request) => Response | Promise<Response>,
  options: HmrReadyFetchOptions = {},
): (request: Request) => Promise<Response> {
  let shouldRetry = options.shouldRetry ?? shouldRetrySafeUnavailableRequest

  return async (request) => {
    while (true) {
      await runner.ready()
      let generation = runner.generation

      try {
        let response = await fetch(request)

        if (!(await shouldRetry({ generation, request, response }))) {
          return response
        }

        await runner.ready()
        if (runner.generation !== generation) continue
        return response
      } catch (error) {
        await runner.ready()
        if (
          runner.generation !== generation &&
          (await shouldRetry({ error, generation, request }))
        ) {
          continue
        }
        throw error
      }
    }
  }
}

/**
 * Starts a Node.js entry module in a supervised child process and watches its loaded module graph.
 *
 * Accepted module changes are applied in place; unaccepted changes restart the child. The returned
 * handle exposes readiness across both paths and closes the watcher, child process, and browser HMR
 * event server when stopped.
 *
 * @param entry Entry module path, resolved from `options.cwd`.
 * @param options Runner options.
 * @returns A runner handle for the supervised process.
 */
export function run(entry: string, options: RunOptions = {}): NodeHmrRunner {
  let supervisor = createHmrSupervisor({
    browserHmrChannel: normalizeBrowserHmrChannelOptions(options.browserHmrChannel),
    cwd: options.cwd ?? process.cwd(),
    entry,
    entryArgs: [...(options.entryArgs ?? [])],
    env: options.env ?? process.env,
    nodeArgs: [...(options.nodeArgs ?? [])],
    registerPath: resolveRegisterPath(),
    watch: options.watch,
  })

  let closed = supervisor.start()
  closed.catch((error: unknown) => {
    console.error(error)
  })

  return {
    close() {
      return supervisor.stop()
    },

    get generation() {
      return supervisor.generation
    },

    ready() {
      return supervisor.ready()
    },
  }
}

function shouldRetrySafeUnavailableRequest({
  request,
  response,
}: HmrReadyFetchRetryContext): boolean {
  if (request.method !== 'GET' && request.method !== 'HEAD') return false

  return (
    response === undefined ||
    response.status === 502 ||
    response.status === 503 ||
    response.status === 504
  )
}

function normalizeBrowserHmrChannelOptions(
  options: RunOptions['browserHmrChannel'],
): BrowserHmrChannelOptions | null {
  if (options === false) return null
  if (options === undefined || options === true) return {}

  if (options.port !== undefined) {
    assertValidPort(options.port)
  }

  return options
}

function resolveRegisterPath(): string {
  let extension = import.meta.url.endsWith('.ts') ? 'ts' : 'js'

  return fileURLToPath(new URL(`./register.${extension}`, import.meta.url))
}

function assertValidPort(port: number): void {
  if (!Number.isInteger(port) || port < 0 || port > 65_535) {
    throw new TypeError(`Invalid browser HMR channel port: ${port}`)
  }
}
