import { type HeaderValue } from './header-value.ts'
import { quote } from './param-values.ts'
import { isIterable } from './utils.ts'

type CookiePair = [name: string, value: string]

/**
 * Initializer for a {@link Cookie} header value.
 */
export type CookieInit = Iterable<[string, string]> | Record<string, string>

/**
 * The value of a `Cookie` HTTP header.
 *
 * [MDN `Cookie` Reference](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cookie)
 *
 * [HTTP/1.1 Specification](https://datatracker.ietf.org/doc/html/rfc6265#section-4.2)
 */
export class Cookie implements HeaderValue, Iterable<[string, string]> {
  #cookies!: CookiePair[]

  constructor(init?: string | CookieInit) {
    if (init) return Cookie.from(init)
    this.#cookies = []
  }

  /**
   * An array of the names of the cookies in the header.
   */
  get names(): string[] {
    return this.#cookies.map(([name]) => name)
  }

  /**
   * An array of the values of the cookies in the header.
   */
  get values(): string[] {
    return this.#cookies.map(([, value]) => value)
  }

  /**
   * The number of cookies in the header.
   */
  get size(): number {
    return this.#cookies.length
  }

  /**
   * Gets the first value of a cookie with the given name from the header.
   *
   * @param name The name of the cookie
   * @returns The first value of the cookie, or `null` if the cookie does not exist
   */
  get(name: string): string | null {
    let cookie = this.#cookies.find(([cookieName]) => cookieName === name)
    return cookie?.[1] ?? null
  }

  /**
   * Gets all values of cookies with the given name from the header.
   *
   * @param name The name of the cookie
   * @returns The values of all matching cookies, or an empty array if none exist
   */
  getAll(name: string): string[] {
    return this.#cookies.filter(([cookieName]) => cookieName === name).map(([, value]) => value)
  }

  /**
   * Sets a cookie with the given name and value in the header, replacing any existing values.
   *
   * @param name The name of the cookie
   * @param value The value of the cookie
   */
  set(name: string, value: string): void {
    let index = this.#cookies.findIndex(([cookieName]) => cookieName === name)

    if (index === -1) {
      this.#cookies.push([name, value])
    } else {
      this.#cookies[index] = [name, value]
      this.#cookies = this.#cookies.filter(
        ([cookieName], cookieIndex) => cookieName !== name || cookieIndex === index,
      )
    }
  }

  /**
   * Appends a cookie with the given name and value to the header.
   *
   * @param name The name of the cookie
   * @param value The value of the cookie
   */
  append(name: string, value: string): void {
    this.#cookies.push([name, value])
  }

  /**
   * Removes all cookies with the given name from the header.
   *
   * @param name The name of the cookie
   */
  delete(name: string): void {
    this.#cookies = this.#cookies.filter(([cookieName]) => cookieName !== name)
  }

  /**
   * True if a cookie with the given name exists in the header.
   *
   * @param name The name of the cookie
   * @returns `true` if a cookie with the given name exists in the header
   */
  has(name: string): boolean {
    return this.#cookies.some(([cookieName]) => cookieName === name)
  }

  /**
   * Removes all cookies from the header.
   */
  clear(): void {
    this.#cookies = []
  }

  /**
   * Returns an iterator of all cookie name and value pairs.
   *
   * @returns An iterator of `[name, value]` tuples
   */
  *entries(): IterableIterator<[string, string]> {
    for (let [name, value] of this.#cookies) {
      yield [name, value]
    }
  }

  /**
   * Iterates over cookie name and value pairs.
   *
   * @returns An iterator of `[name, value]` tuples.
   */
  [Symbol.iterator](): IterableIterator<[string, string]> {
    return this.entries()
  }

  /**
   * Invokes the callback for each cookie name and value pair.
   *
   * @param callback The function to call for each pair
   * @param thisArg The value to use as `this` when calling the callback
   */
  forEach(callback: (name: string, value: string, header: Cookie) => void, thisArg?: any): void {
    for (let [name, value] of this) {
      callback.call(thisArg, name, value, this)
    }
  }

  /**
   * Returns the string representation of the header value.
   *
   * @returns The header value as a string
   */
  toString(): string {
    let pairs: string[] = []

    for (let [name, value] of this.#cookies) {
      pairs.push(`${name}=${quote(value.replace(/;/g, '%3B'))}`)
    }

    return pairs.join('; ')
  }

  /**
   * Parse a Cookie header value.
   *
   * @param value The header value (string, init object, or null)
   * @returns A Cookie instance (empty if null)
   */
  static from(value: string | CookieInit | null): Cookie {
    let header = new Cookie()

    if (value !== null) {
      if (typeof value === 'string') {
        // Cookie semicolons delimit pairs even inside quotes, per RFC 6265.
        // https://www.rfc-editor.org/rfc/rfc6265.html#section-4.1.1
        for (let piece of value.split(';')) {
          let match = /^\s*([^=\s]+)(\s*=\s*)?/.exec(piece)
          if (match === null) continue

          let val = match[2] ? piece.slice(match[0].length) : ''
          // Preserve unmatched quotes instead of applying HTTP parameter recovery.
          let quoted = /^"((?:[^"\\]|\\.)*)"/.exec(val)
          if (quoted !== null) val = quoted[1]
          header.#cookies.push([match[1], val.replace(/\\(.)/g, '$1').trim()])
        }
      } else if (isIterable(value)) {
        for (let [name, val] of value) {
          header.#cookies.push([name, val])
        }
      } else {
        for (let name of Object.getOwnPropertyNames(value)) {
          header.#cookies.push([name, value[name]])
        }
      }
    }

    return header
  }
}
