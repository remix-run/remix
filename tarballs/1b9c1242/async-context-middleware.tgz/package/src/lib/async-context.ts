import { AsyncLocalStorage } from 'node:async_hooks'

import type {
  AnyParams,
  ContextEntries,
  ContextWithEntries,
  Middleware,
  RequestContext,
  RouterTypes,
} from '@remix-run/fetch-router'

type RequestContextWithAnyParams<context> =
  context extends RequestContext<any, infer entries extends ContextEntries>
    ? ContextWithEntries<RequestContext<AnyParams>, entries>
    : RequestContext<AnyParams>

export type AsyncRequestContext = RouterTypes extends {
  context: infer context extends RequestContext<any, any>
}
  ? RequestContextWithAnyParams<context>
  : RequestContext<AnyParams>

const storage = new AsyncLocalStorage<RequestContext<any, any>>()

/**
 * Middleware that stores the request context in `AsyncLocalStorage` so it is available
 * to all functions in the same async execution context.
 *
 * @returns A middleware function that stores the request context in `AsyncLocalStorage`
 */
export function asyncContext(): Middleware {
  return (context, next) => storage.run(context, next)
}

/**
 * Get the request context from `AsyncLocalStorage`.
 *
 * @returns The request context
 */
export function getContext(): AsyncRequestContext {
  let context = storage.getStore()

  if (context == null) {
    throw new Error('No request context found. Make sure the asyncContext middleware is installed.')
  }

  return context as AsyncRequestContext
}
