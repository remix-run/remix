import type { Middleware, RequestContext } from '@remix-run/fetch-router'
import { renderWith, type Renderer } from '@remix-run/render-middleware'
import {
  run as runRuntime,
  spaResponse,
  type AppRuntime,
  type RemixNode,
  type ResolveFrameOptions,
} from '@remix-run/component'

/** Creates a response that the SPA runtime can render. */
export interface Render {
  /**
   * Creates a renderable route response.
   *
   * @param node Node to render.
   * @param init Optional response status and headers.
   * @returns A response understood by the SPA runtime.
   */
  (node: RemixNode, init?: ResponseInit): Response
}

/** Transforms a route node before the SPA runtime renders it. */
export interface RenderTransform {
  /**
   * Transforms a node using the active request context.
   *
   * @param node Node returned by the route.
   * @param context Active request context.
   * @returns The node to render.
   */
  (node: RemixNode, context: RequestContext): RemixNode
}

/** Minimal router contract used by {@link run}. */
export interface Router {
  fetch(input: string | URL | Request, init?: RequestInit): Promise<Response>
}

/** Client runtime returned by {@link run}. */
export type Runtime = Omit<AppRuntime, 'ready'> & {
  /** Resolves after the client runtime starts and the initial route renders. */
  ready(): Promise<void>
}

/** Options for starting a client-rendered Remix application. */
export interface RunOptions {
  /** Remix node to display while the initial route loads. */
  fallback?: RemixNode
}

type RenderMiddleware = Middleware<{
  key: typeof Renderer
  value: Render
  property: 'render'
}>

const redirectStatuses = new Set([301, 302, 303, 307, 308])
const maxRedirects = 10

/**
 * Creates middleware that exposes `context.render()` for SPA route responses.
 *
 * @param transform Optional transform that wraps or replaces route nodes.
 * @returns Middleware that installs the SPA renderer on request context.
 */
export function render(transform?: RenderTransform): RenderMiddleware {
  return renderWith(
    (context) =>
      function render(node: RemixNode, init?: ResponseInit): Response {
        return spaResponse.create(transform ? transform(node, context) : node, init)
      },
  )
}

/**
 * Starts a client-rendered Remix application for the current document.
 *
 * The current URL and subsequent same-origin navigations are dispatched through `router`. Route
 * handlers return responses created by the {@link render} middleware, and their associated nodes
 * are rendered into the document's top frame.
 *
 * @param router Router that resolves browser requests to SPA route responses.
 * @param options Options for the initial render.
 * @returns The running application runtime.
 */
export function run(router: Router, options: RunOptions = {}): Runtime {
  let app = runRuntime({
    loadModule() {
      throw new Error('SPA responses cannot hydrate client entries')
    },
    async resolveFrame(src, options) {
      let url = new URL(src, document.baseURI)
      let { body, encType } = getRequestBody(options)
      let headers = new Headers()
      if (encType) headers.set('Content-Type', encType)
      let requestInit: RequestInit = {
        method: options?.method,
        body,
        headers,
        signal: options?.signal,
      }
      let { response, redirectedTo } = await followFrameRedirects(router, url, requestInit)
      return spaResponse.finalize(response, redirectedTo)
    },
  })

  let readyPromise = app.ready().then(async () => {
    if (options.fallback !== undefined) {
      await app.frames.top.replace(options.fallback)
    }
    await app.frames.top.reload()
  })

  return Object.assign(app, {
    ready: () => readyPromise,
  })
}

async function followFrameRedirects(
  router: Router,
  url: URL,
  init: RequestInit,
): Promise<{ response: Response; redirectedTo?: string }> {
  let initialOrigin = url.origin
  let method = init.method?.toUpperCase() ?? 'GET'
  let body = init.body
  let headers = new Headers(init.headers)
  let redirectedTo: string | undefined

  for (let redirectCount = 0; redirectCount <= maxRedirects; redirectCount++) {
    let response = await router.fetch(url, { ...init, method, body, headers })
    if (!redirectStatuses.has(response.status)) {
      return { response, redirectedTo }
    }

    let location = response.headers.get('Location')
    if (!location) return { response }
    if (redirectCount === maxRedirects) {
      throw new TypeError(`SPA route exceeded ${maxRedirects} redirects`)
    }

    let nextUrl = new URL(location, url)
    if (nextUrl.origin !== initialOrigin) {
      throw new TypeError('SPA routes cannot redirect to another origin')
    }

    if (
      (response.status === 303 && method !== 'GET' && method !== 'HEAD') ||
      ((response.status === 301 || response.status === 302) && method === 'POST')
    ) {
      method = 'GET'
      body = undefined
      headers.delete('Content-Type')
    }

    url = nextUrl
    redirectedTo = url.href
  }

  throw new TypeError(`SPA route exceeded ${maxRedirects} redirects`)
}

function getRequestBody(options?: ResolveFrameOptions): {
  body?: BodyInit
  encType?: string
} {
  let formData = options?.formData
  if (!formData) return {}
  if (['get', 'head'].includes((options?.method ?? 'get').toLowerCase())) return {}

  let encType = options?.encType?.toLowerCase()

  if (encType === 'multipart/form-data') return { body: formData }

  if (encType === 'text/plain') {
    let body = ''
    for (let [name, value] of formData) {
      name = normalizeLineBreaks(name)
      value = normalizeLineBreaks(typeof value === 'string' ? value : value.name)
      body += `${name}=${value}\r\n`
    }
    return { body: new Blob([body], { type: 'text/plain' }), encType: 'text/plain' }
  }

  let body = new URLSearchParams()
  for (let [name, value] of formData) {
    body.append(
      normalizeLineBreaks(name),
      normalizeLineBreaks(typeof value === 'string' ? value : value.name),
    )
  }
  return { body, encType: 'application/x-www-form-urlencoded' }
}

function normalizeLineBreaks(value: string): string {
  return value.replace(/\r\n|\r|\n/g, '\r\n')
}
