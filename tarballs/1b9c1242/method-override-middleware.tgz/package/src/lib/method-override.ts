import { isRequestMethod } from '@remix-run/fetch-router'
import type { Middleware } from '@remix-run/fetch-router'

/**
 * Options for the {@link methodOverride} middleware.
 */
export interface MethodOverrideOptions {
  /**
   * The name of the form field to check for request method override.
   *
   * @default '_method'
   */
  fieldName?: string
}

/**
 * Middleware that overrides `context.method` with the value of the method override field.
 *
 * Note: This middleware must be placed after the
 * {@link import('@remix-run/form-data-middleware').formData} middleware in the middleware
 * chain, or some other middleware that provides `context.get(FormData)`.
 *
 * @param options Options for the method override middleware
 * @returns A middleware that overrides `context.method` with the value of the method override field
 */
export function methodOverride(options?: MethodOverrideOptions): Middleware {
  let fieldName = options?.fieldName ?? '_method'

  return (context, next) => {
    let method = context.get(FormData)?.get(fieldName)

    if (typeof method === 'string') {
      let requestMethod = method.toUpperCase()

      if (isRequestMethod(requestMethod)) {
        context.method = requestMethod
      }
    }

    return next()
  }
}
