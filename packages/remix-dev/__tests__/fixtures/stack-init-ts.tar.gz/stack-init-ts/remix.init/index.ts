// this is the init file
export const main = ({ rootDirectory }: { rootDirectory: string }) => {
  console.log("Running init script on " + rootDirectory);
};

export default main;
