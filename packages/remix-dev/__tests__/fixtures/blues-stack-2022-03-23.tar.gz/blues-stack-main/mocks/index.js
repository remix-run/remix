require("esbuild-register/dist/node").register();
require("./start");
