import etag from 'etag';

export { etag };
