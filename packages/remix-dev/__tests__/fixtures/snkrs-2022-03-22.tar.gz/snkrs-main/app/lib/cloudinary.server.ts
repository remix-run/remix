import cloudinary from 'cloudinary';

export { cloudinary };
