export { type FileStorage } from './lib/file-storage.js';
