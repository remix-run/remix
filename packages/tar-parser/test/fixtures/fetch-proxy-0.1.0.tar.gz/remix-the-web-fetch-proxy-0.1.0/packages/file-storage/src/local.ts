export { LocalFileStorage } from './lib/local-file-storage.js';
