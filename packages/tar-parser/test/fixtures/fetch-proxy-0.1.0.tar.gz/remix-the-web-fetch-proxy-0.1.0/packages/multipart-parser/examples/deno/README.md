# multipart-parser Deno Example

This example demonstrates handling a `<form enctype="multipart/form-data">` POST to [a Deno server](https://deno.com/) and streaming any file uploads it contains to a tmp directory on the filesystem.
