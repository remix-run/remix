# multipart-parser Bun Example

This is an example of handling a `<form enctype="multipart/form-data">` POST to [a Bun server](https://bun.sh) and streaming any files it contains to a tmp directory on the filesystem.
