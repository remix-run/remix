# multipart-parser Node Example

This example is a simple [Node.js server](https://nodejs.org/) that handles file uploads and streams them to a tmp file on disk.
