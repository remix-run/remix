export { type FetchProxyOptions, type FetchProxy, createFetchProxy } from './lib/fetch-proxy.js';
