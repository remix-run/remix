export interface HeaderValue {
  toString(): string;
}
