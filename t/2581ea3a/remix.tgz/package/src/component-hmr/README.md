# component-hmr

Hot module replacement transforms for Remix components, with integrations for Node and `remix/assets`.

`component-hmr` rewrites supported Remix component modules so they can use the standard `import.meta.hot` APIs provided by packages like [`assets`](../assets/README.md) and [`node-hmr`](../node-hmr/README.md).

## Features

- **Stable Components** - Keep component identity stable while swapping implementations
- **Remount Fallbacks** - Mark components stale when their setup scope changes
- **Node Module Hooks** - Transform server component modules through Node's module customization hooks API
- **Assets Loader** - Transform component modules for the browser through `remix/assets`

## Installation

```sh
npm i remix
```

## Usage

Use `remix/component-hmr/node` as a Node import hook for server modules:

```sh
node --import remix/node-tsx --import remix/component-hmr/node ./server.ts
```

Use `componentHmr()` from `remix/component-hmr/assets` with `remix/assets` for browser modules:

```ts
import { createAssetServer } from 'remix/assets'
import { componentHmr } from 'remix/component-hmr/assets'

let isDevelopment = process.env.NODE_ENV === 'development'

let assetServer = createAssetServer({
  basePath: '/assets',
  allowFiles: ['app/routes.ts', 'app/**/public/**'],
  allowPackages: ['remix'],
  denyFiles: ['app/**/*.test.*'],
  hmr: isDevelopment
    ? {
        channel: async () => (await import('remix/node-hmr/runtime')).createBrowserHmrChannel(),
        moduleImporter: 'remix/multiple-import-maps-polyfill',
      }
    : undefined,
  scripts: {
    loaders: isDevelopment ? [componentHmr()] : undefined,
  },
  watch: isDevelopment,
})
```

HMR appends mappings for updated modules to the document in additional `<script type="importmap">` elements. The module importer allows browsers without native support for multiple import maps to load these updates.

## Direct Transforms

Use the direct transform APIs when you are writing your own loader, Node module hooks, or build integration.

```ts
import { transformComponentsForBrowser } from 'remix/component-hmr'

let result = transformComponentsForBrowser(source, {
  importSource: 'remix',
  moduleUrl: '/assets/app/routes.tsx',
})

if (result.transformed) {
  console.log(result.componentNames)
}
```

`transformComponentsForBrowser(source, options)` rewrites browser component modules and emits `import.meta.hot.accept()` code for browser updates. The direct transform uses `importSource` to derive imports for the component refresh runtime and browser HMR runtime.

```ts
import { transformComponentsForServer } from 'remix/component-hmr'

let result = transformComponentsForServer(source, {
  importSource: 'remix',
  moduleUrl: 'file:///app/routes.tsx',
})
```

`transformComponentsForServer(source, options)` rewrites server component modules and registers updated component implementations for the current module URL. The direct transform uses `importSource` to derive imports for the server HMR runtime.

Both transforms return:

```ts
type ComponentsHmrTransformResult = {
  code: string
  componentNames: string[]
  map: string | null
  transformed: boolean
}
```

Pass `sourceMap: true` to generate a source map.

Use `importSource` to define where injected imports come from, typically either `remix` or `@remix-run`:

```ts
transformComponentsForBrowser(source, {
  importSource: 'remix',
  moduleUrl: '/assets/app/routes.tsx',
})

transformComponentsForServer(source, {
  importSource: 'remix',
  moduleUrl: 'file:///app/routes.tsx',
})
```

`importSource: 'remix'` generates imports from `remix/component` and `remix/component-hmr`. `importSource: '@remix-run'` generates imports from `@remix-run/component` and `@remix-run/component-hmr`. Custom import sources follow the same nested import layout.

## Related Packages

- [`assets`](../assets/README.md) - Runs loaders while compiling assets
- [`node-hmr`](../node-hmr/README.md) - Provides the server-side `import.meta.hot` runtime
- [`component`](../component/README.md) - Component APIs transformed by `component-hmr`

## License

See [LICENSE](https://github.com/remix-run/remix/blob/main/LICENSE)
