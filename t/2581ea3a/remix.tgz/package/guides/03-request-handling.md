---
title: Request Handling
description: How a Web Request becomes a Web Response across runtime adapters and the middleware pipeline.
---

This guide follows a request from the server boundary to the [controller action](/routing-and-controllers/#controllers-and-actions) that handles it. It covers how a runtime hands the app a Web [`Request`](https://developer.mozilla.org/en-US/docs/Web/API/Request), how middleware prepares request context, and how the resulting Web [`Response`](https://developer.mozilla.org/en-US/docs/Web/API/Response) gets back to the client.

The runtime-specific code stays in the server entry. The router, middleware, and actions work with the same Fetch API contract everywhere else.

## The Web Request/Response contract {#the-web-request-response-contract}

A Remix router is a fetch handler. Its `fetch()` method accepts a URL or Web `Request` and resolves to a Web `Response`:

```ts
let request = new Request("https://albums.example/albums/thriller", {
  method: "GET",
  headers: { Accept: "text/html" },
});

let response = await router.fetch(request);

console.log(response.status); // 200
console.log(response.headers.get("Content-Type"));
```

That call is the same whether it comes from a Node server, a Bun server, a Cloudflare Worker, or a test. The runtime adapter does not define routes or know how pages render. It only bridges its native server API to `Request` and `Response` when a bridge is needed.

For each call to `router.fetch(...)`, Remix:

1. Creates request context from the incoming `Request`.
2. Runs router middleware.
3. Matches `context.method` and `context.url` against the registered routes.
4. Runs controller and action middleware for the matched route.
5. Calls the action and receives its `Response`.
6. Unwinds the middleware chain, then resolves `router.fetch(...)` with the final response.

If no route matches, the router returns a `404` response. If middleware or an action throws, `router.fetch(...)` rejects. The server entry is the last place to catch that error and turn it into a `500` response.

Request and response bodies stay as Web streams. An action can read `request.body`, return a `Response` backed by a [`ReadableStream`](https://developer.mozilla.org/en-US/docs/Web/API/ReadableStream), and respond to cancellation through `request.signal`, an [`AbortSignal`](https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal) that fires when the client goes away, without dropping down to a runtime-specific request object.

## The Node server entry {#the-node-server-entry}

On Node, `server.ts` creates a `node:http` server and connects it to the app router. A production entry should also [shut down gracefully](/production/#startup-and-shutdown), which this example omits to keep the request path visible.

```ts filename=server.ts
import * as http from "node:http";
import { createRequestListener } from "remix/node-fetch-server";

import { router } from "./app/router.ts";

const port = process.env.PORT ? Number.parseInt(process.env.PORT, 10) : 44100;

const server = http.createServer(createRequestListener(router.fetch));

server.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});
```

`server.ts` owns Node concerns such as the port, TLS, shutdown signals, and any integration that needs Node's raw request or response objects. `app/router.ts` owns application concerns such as middleware, routes, and controllers.

Keep that boundary narrow. Code that only needs a URL, headers, cookies, a body, or an abort signal can use Web APIs on the other side of `createRequestListener`.

## createRequestListener {#createrequestlistener}

`createRequestListener(...)` adapts a Fetch handler to the callback expected by `http.createServer(...)`. For each Node request, it:

- Constructs the full request URL from the protocol, host, and incoming path.
- Exposes the incoming headers and body through a Web `Request`.
- Aborts `request.signal` if the client disconnects.
- Passes the request to your Fetch handler.
- Writes the returned response status, headers, and streamed body through Node.

The same listener works with `node:http`, `node:https`, and Node's HTTP/2 compatibility API. `createRequestListener(...)` logs errors and returns a generic `500` response by default.

The listener accepts a few options when the server boundary needs more information:

| Option       | Use                                                                                                                   |
| ------------ | --------------------------------------------------------------------------------------------------------------------- |
| `host`       | Set a fixed host when constructing `request.url`.                                                                     |
| `protocol`   | Set a fixed protocol such as `"https:"`.                                                                              |
| `trustProxy` | Read trusted `Forwarded` and `X-Forwarded-*` headers for the URL and client address.                                  |
| `onError`    | Log an uncaught error and optionally return the `Response` that should be sent instead of the default `500` response. |

Proxies use the [`Forwarded`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Forwarded) header, or the older `X-Forwarded-*` headers, to pass along the protocol, host, and client address of the original request. A Node server behind a trusted reverse proxy can let the listener recover the public protocol and host:

```ts filename=server.ts
const requestListener = createRequestListener(router.fetch, {
  trustProxy: true,
  onError(error) {
    console.error(error);
    return new Response("Internal Server Error", { status: 500 });
  },
});

const server = http.createServer(requestListener);
```

Only enable `trustProxy` when clients cannot reach the app server without going through a proxy that overwrites those headers. Otherwise, a client can spoof the protocol, host, or address your app sees.

A handler may also accept a second argument with the client address, address family, and port:

```ts
const requestListener = createRequestListener((request, client) => {
  console.log(`Request from ${client.address}:${client.port}`);
  return router.fetch(request);
});
```

If an existing Node integration needs lower-level control, [`remix/node-fetch-server`](../src/node-fetch-server/README.md) also exports `createRequest(...)` and `sendResponse(...)`. Prefer `createRequestListener(...)` until you need to work between those two operations.

## Alternate runtimes: Bun, Deno, Workers {#alternate-runtimes-bun-deno-workers}

Bun, Deno, and edge worker runtimes already accept Fetch handlers, so they do not need the Node adapter. Their entrypoints can call the same router directly.

Bun uses the handler in `Bun.serve(...)`:

```ts filename=server.ts
import { router } from "./app/router.ts";

Bun.serve({
  port: 44100,
  fetch(request) {
    return router.fetch(request);
  },
});
```

Deno uses the handler in `Deno.serve(...)`:

```ts filename=server.ts
import { router } from "./app/router.ts";

Deno.serve({ port: 44100 }, router.fetch);
```

A Cloudflare Worker exports an object with a `fetch` method:

```ts filename=worker.ts
import { router } from "./app/router.ts";

export default {
  fetch(request) {
    return router.fetch(request);
  },
} satisfies ExportedHandler;
```

These abbreviated entries omit the error logging from the Node example. Add a `try`/`catch` around `router.fetch(...)` when the runtime's default error response and logging are not what the app needs.

The router contract is portable, but every package in a middleware stack may not be. For example, the current static-file and compression middleware use Node filesystem and compression APIs. On a worker, serve static assets through the platform and use the platform's response compression instead.

## Middleware ordering {#middleware-ordering}

Middleware wraps every request that `router.fetch(...)` handles. Given two middleware functions, the request runs from left to right and the response unwinds from right to left:

```txt
request  → first → second → action
response ← first ← second ← action
```

That order comes from `next()`:

```ts
import type { Middleware } from "remix/router";

function timing(): Middleware {
  return async (context, next) => {
    let start = performance.now();
    let response = await next();
    let duration = performance.now() - start;

    console.log(`${context.method} ${context.url.pathname} ${duration.toFixed(1)}ms`);
    return response;
  };
}
```

Code before `await next()` runs on the way in. Code after it runs on the way out and can inspect or replace the downstream response. Returning a `Response` without calling `next()` stops the chain, which is how static files, [CORS preflights](https://developer.mozilla.org/en-US/docs/Glossary/Preflight_request), authorization checks, and caches can answer a request early.

Remix has three middleware scopes:

1. **Router middleware** runs before route matching for every request passed to the router.
2. **Controller middleware** runs for the direct actions owned by that controller.
3. **Action middleware** runs for one action.

The complete order is router middleware, controller middleware, action middleware, then the action handler. Controller and action middleware only run after a route matches. Controller middleware does not flow into controllers [mapped for nested route maps](/routing-and-controllers/#mapping-controllers).

Choose middleware order by dependency and wrapping behavior:

- Put a provider before its consumer, such as `formData()` before `methodOverride()`.
- Put a response wrapper before an early response it should transform, such as `compression()` before `staticFiles()`.
- Put work that a fast path does not need after that fast path, such as rendering setup after static files.

The same rules apply to sessions, [CSRF protection](/auth-sessions-security/#csrf-protection), and authentication. Load a session before middleware reads it, parse form data before checking a form token, and resolve authentication before requiring an authenticated user.

## Typed request context {#typed-request-context}

Every middleware and action in one `router.fetch(...)` call receives the same request context object. It starts with the original `request`, parsed `url`, a mutable `Headers` copy, the effective `method`, matched `params`, and the current `router`. Middleware can add request-scoped values with `context.set(key, value)`, and downstream code reads them with `context.get(key)`.

Built-in middleware carries its context changes in its TypeScript type. For example, `formData()` provides `context.formData`, while `render()` provides the typed `context.render(...)` function.

In `app/router.ts`, derive the application context from the configured router and use [module augmentation](https://www.typescriptlang.org/docs/handbook/declaration-merging.html#module-augmentation) to make that context the default for controllers. Module augmentation is a TypeScript `declare module` block that adds fields to an interface exported by another package, here the `RouterTypes` interface from `remix`:

```ts filename=app/router.ts
import { formData } from "remix/middleware/form-data";
import { render } from "remix/middleware/render";
import { staticFiles } from "remix/middleware/static";
import { createRouter, type RouterContext } from "remix/router";

import controller from "./actions/controller.tsx";
import albumsController from "./actions/albums/controller.tsx";
import albumsEditController from "./actions/albums/edit/controller.tsx";
import { assets } from "./assets.ts";
import { routes } from "./routes.ts";

export const router = createRouter({
  middleware: [staticFiles("./public", { index: false }), formData(), render({ assets })],
});

export type AppContext = RouterContext<typeof router>;

declare module "remix" {
  interface RouterTypes {
    context: AppContext;
  }
}

router.map(routes, controller);
router.map(routes.albums, albumsController);
router.map(routes.albums.edit, albumsEditController);
```

`RouterContext<typeof router>` follows the inline middleware tuple in order. In any controller mapped to this router, such as the album edit controller, TypeScript knows that `context.formData` and `context.render` are present:

```tsx filename=app/actions/albums/edit/controller.tsx
// inside the actions object:
action(context) {
  let title = context.formData.get("title");

  return context.render(<p>Submitted {String(title)}</p>);
},
```

The module augmentation is useful because controllers are created in separate files before they are mapped to this router. Apps with multiple routers should pass explicit context types instead of setting one application-wide default.

When a reusable middleware chain must be stored in a variable, `createMiddleware(...)` preserves its tuple type and `MiddlewareContext<typeof middleware>` derives the resulting context. Inline middleware arrays and `RouterContext<typeof router>` are the simpler default.

Request context is still an explicit per-request value, not a global. If a helper outside middleware or an action must reach it, add `asyncContext()` from [`remix/middleware/async-context`](../src/async-context-middleware/README.md) and call `getContext()` inside that helper. That middleware uses Node's [`AsyncLocalStorage`](https://nodejs.org/api/async_context.html), so passing the needed value as a function argument remains the portable option.

## Common middleware: form-data, render, static files, compression, logging {#common-middleware}

A server-rendered app usually needs at least static-file and render middleware. Add the others when the request path needs them:

| Middleware      | Import                                                         | What it does                                                                                                                | Placement                                                                                       |
| --------------- | -------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| `formData()`    | [`remix/middleware/form-data`](../src/form-data-middleware/README.md)     | Parses URL-encoded and multipart bodies once, then provides `context.formData`. Non-form requests receive empty `FormData`. | Before CSRF form-field checks or actions that read parsed form data.                            |
| `render()`      | [`remix/middleware/render`](../src/render-middleware/README.md)           | Installs the standard Remix component `context.render(...)` function.                                                       | After middleware that may answer without rendering.                                             |
| `staticFiles()` | [`remix/middleware/static`](../src/static-middleware/README.md)           | Serves `GET` and `HEAD` requests from a directory, with conditional and range request support.                              | Early, before request enrichment that static files do not need.                                 |
| `compression()` | [`remix/middleware/compression`](../src/compression-middleware/README.md) | Negotiates Brotli, gzip, or deflate for suitable downstream responses.                                                      | Before every response it should wrap, including `staticFiles()` when static text is compressed. |
| `logger()`      | [`remix/middleware/logger`](../src/logger-middleware/README.md)           | Logs the request and downstream response and provides `context.logger(...)`.                                                | Usually first so early responses and `404`s are logged.                                         |

A server-rendered app that accepts HTML forms might use all five:

```ts filename=app/router.ts
import { compression } from "remix/middleware/compression";
import { formData } from "remix/middleware/form-data";
import { logger } from "remix/middleware/logger";
import { render } from "remix/middleware/render";
import { staticFiles } from "remix/middleware/static";
import { createRouter } from "remix/router";

import { assets } from "./assets.ts";

export const router = createRouter({
  middleware: [
    logger(),
    compression(),
    staticFiles("./public", { index: false }),
    formData(),
    render({ assets }),
  ],
});
```

Global middleware is convenient when most routes use it. If only one action accepts a form or upload, put `formData()` on that action instead so other requests skip body parsing.

`staticFiles()` serves files exactly as they exist under the root `public/` directory. Browser source compiled by [`remix/assets`](../src/assets/README.md) lives in colocated `public/` directories under `app/` and goes through a separate [source-served asset pipeline](/files-and-assets/#how-the-asset-server-works).

`render()` from [`remix/middleware/render`](../src/render-middleware/README.md) is what lets actions [render component pages](/rendering-ui/#rendering-pages-through-request-context) with `context.render(...)`, backed by the [streaming renderer](/streaming-ui-with-frames/#server-rendering-with-rendertostream-and-rendertostring).

## Custom middleware {#custom-middleware}

A custom middleware is a function that receives `(context, next)` and returns a `Response` or the response from `next()`. When it provides a request-scoped value, create a context key with `createContextKey<T>()`. The key is the typed handle that `context.set(key, value)` and `context.get(key)` use to store and read that value.

This middleware assigns a request ID before the action runs, then adds the same ID to the response on the way out:

```ts filename=app/middleware/request-id.ts
import { createContextKey, type Middleware } from "remix/router";

export const RequestId = createContextKey<string>();

export function requestId(): Middleware<{
  key: typeof RequestId;
  value: string;
}> {
  return async (context, next) => {
    let id = crypto.randomUUID();
    context.set(RequestId, id);

    let response = await next();
    let headers = new Headers(response.headers);
    headers.set("X-Request-Id", id);

    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
  };
}
```

The `Middleware<{ key, value }>` type records what the middleware adds. Once `requestId()` is part of the typed router stack, downstream controllers read `context.get(RequestId)` as a `string` rather than `string | undefined`.

A middleware that rejects a request returns its response without calling `next()`:

```ts
function requireJson(): Middleware {
  return (context, next) => {
    let mediaType = context.headers.get("Content-Type")?.split(";", 1)[0].trim().toLowerCase();

    if (mediaType !== "application/json") {
      return new Response("Expected JSON", { status: 415 });
    }

    return next();
  };
}
```

Keep custom middleware focused on one request-lifecycle concern. Route-specific data loading or validation usually belongs in the action, while behavior shared across many routes fits the middleware pipeline. Request IDs, sessions, authentication, security headers, and database access are common examples.
