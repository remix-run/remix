import { createMixin, renderMixinElement } from '../runtime/mixins/mixin.ts'
import type { MixinFactory } from '../runtime/mixins/mixin.ts'
import type { MixinDescriptor } from '../runtime/mixins/mixin.ts'
import type { ElementProps } from '../runtime/jsx.ts'
import { invariant } from '../runtime/invariant.ts'
import { processStyleClass } from '../style/index.ts'
import type { CSSProps } from '../style/style.ts'

type StyleEntry = { selector: string; css: string }
type StyleCache = Map<string, StyleEntry>
type StyleManagerLike = {
  insert(className: string, rule: string): void
  remove(className: string): void
  getGeneration?(): number
}

/**
 * Descriptor produced by `css(...)` for composing generated styles with other host mixins.
 */
export type CSSMixinDescriptor = MixinDescriptor<Element, [styles: CSSProps], ElementProps>

const clientStyleCache: StyleCache = new Map()

/**
 * Applies generated class names for CSS object styles.
 */
export const css: MixinFactory<Element, [styles: CSSProps], ElementProps> = createMixin<
  Element,
  [styles: CSSProps],
  ElementProps
>((handle) => {
  let activeSelector = ''
  let activeGeneration = -1
  let currentStyles: CSSProps = {}

  handle.addEventListener('remove', () => {
    if (!activeSelector) return
    let runtime = handle.frame.$runtime as {
      styleCache?: StyleCache
      styleManager?: StyleManagerLike
    }
    invariant(runtime, 'css mixin requires frame runtime')
    let styleTarget = resolveStyleTarget(runtime)
    styleTarget.styleManager?.remove(activeSelector)
    activeSelector = ''
    activeGeneration = -1
  })

  return (styles, props) => {
    currentStyles = styles
    let runtime = handle.frame.$runtime as {
      styleCache?: StyleCache
      styleManager?: StyleManagerLike
    }
    invariant(runtime, 'css mixin requires frame runtime')
    let styleTarget = resolveStyleTarget(runtime)
    let { selector, css: cssText } = processStyleClass(currentStyles, styleTarget.styleCache)
    let styleGeneration = styleTarget.styleManager?.getGeneration?.() ?? 0

    if (styleTarget.styleManager) {
      if (activeSelector && activeSelector !== selector) {
        styleTarget.styleManager.remove(activeSelector)
      }
      if (selector && (activeSelector !== selector || activeGeneration !== styleGeneration)) {
        styleTarget.styleManager.insert(selector, cssText)
      }
      activeSelector = selector
      activeGeneration = selector ? styleGeneration : -1
    }

    if (!selector) {
      return handle.element
    }

    return renderMixinElement(handle.element, {
      ...(props ?? {}),
      className: props?.className ? `${props.className} ${selector}` : selector,
    })
  }
})

function resolveStyleTarget(runtime: {
  styleCache?: StyleCache
  styleManager?: StyleManagerLike
}): { styleCache: StyleCache; styleManager?: StyleManagerLike } {
  return {
    styleCache: runtime.styleCache ?? clientStyleCache,
    styleManager: runtime.styleManager,
  }
}
