import type { TestResults } from './reporters/results.ts'
import { runServerTestFile } from './worker-server.ts'
import { createFailedResults } from './worker-results.ts'

const workerData = await readWorkerData()

const results = await runWorkerProcessFile(workerData)

if (results) {
  await sendResults(results)
}

if (process.connected) {
  process.disconnect()
}

process.exitCode = 0

function readWorkerData(): Promise<unknown> {
  return new Promise((resolve, reject) => {
    function cleanup() {
      process.off('message', onMessage)
      process.off('disconnect', onDisconnect)
    }

    function onMessage(value: unknown) {
      cleanup()
      resolve(value)
    }

    function onDisconnect() {
      cleanup()
      reject(new Error('Test worker process disconnected'))
    }

    process.once('message', onMessage)
    process.once('disconnect', onDisconnect)
  })
}

async function runWorkerProcessFile(value: unknown): Promise<TestResults | undefined> {
  try {
    if (!isRecord(value) || (value.type !== 'server' && value.type !== 'e2e')) {
      throw new Error('Invalid test worker process data')
    }

    if (value.type === 'e2e') {
      let { runE2ETestFile } = await import('./worker-e2e-file.ts')
      return await runE2ETestFile(value, sendResults)
    }

    return await runServerTestFile(value)
  } catch (error) {
    return createFailedResults(error)
  }
}

async function sendResults(results: TestResults): Promise<void> {
  if (!process.send) {
    throw new Error('Test worker process is missing an IPC channel')
  }

  let send = process.send.bind(process)
  await new Promise<void>((resolve, reject) => {
    send(results, undefined, undefined, (error) => (error ? reject(error) : resolve()))
  })
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}
