import type { ParsedPattern, Token } from './parse.ts'

// oxfmt-ignore
export type Stringify<T extends ParsedPattern> =
  HasOrigin<T> extends true ?
    `${StringifyTokens<T['protocol'], ''>}://${StringifyTokens<T['hostname'], '.'>}${StringifyPort<T['port']>}${StringifyPathname<T['pathname']>}${StringifySearch<T['search']>}` :
    `${StringifyPathname<T['pathname']>}${StringifySearch<T['search']>}`

type HasOrigin<T extends ParsedPattern> = T['protocol'] extends Token[]
  ? true
  : T['hostname'] extends Token[]
    ? true
    : T['port'] extends string
      ? true
      : false

// oxfmt-ignore
type StringifyTokens<T extends Token[] | undefined, Sep extends string> =
  T extends undefined ? '' :
  T extends [] ? '' :
  T extends [infer Head extends Token, ...infer Tail extends Token[]] ?
    `${StringifyToken<Head, Sep>}${StringifyTokens<Tail, Sep>}` :
    never

// oxfmt-ignore
type StringifyToken<T extends Token, Sep extends string> =
  T extends { type: 'text', value: infer V extends string } ? V :
  T extends { type: 'variable', name: infer N extends string } ? `:${N}` :
  T extends { type: 'wildcard', name: infer N extends string } ? `*${N}` :
  T extends { type: 'wildcard' } ? '*' :
  T extends { type: 'separator' } ? Sep :
  T extends { type: 'optional', tokens: infer Tokens extends Token[] } ? `(${StringifyTokens<Tokens, Sep>})` :
  never

// oxfmt-ignore
type StringifyPathname<T extends Token[] | undefined> =
  T extends undefined ? '/' :
  T extends [] ? '/' :
  T extends Token[] ?
    StartsWithSeparator<T> extends true ?
      `${StringifyTokens<T, '/'>}` :
      `/${StringifyTokens<T, '/'>}` :
    never

type StringifyPort<T extends string | undefined> = T extends string ? `:${T}` : ''

type StringifySearch<T extends string | undefined> = T extends string ? `?${T}` : ''

// oxfmt-ignore
export type StartsWithSeparator<T extends Token[]> =
  T extends [] ? false :
  T extends [{ type: 'separator' }, ...Token[]] ? true :
  T extends [{ type: 'optional', tokens: infer Tokens extends Token[] }, ...Token[]] ?
    StartsWithSeparator<Tokens> :
    false
