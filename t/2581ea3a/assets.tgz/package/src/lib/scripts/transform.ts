import * as fs from 'node:fs'
import * as fsp from 'node:fs/promises'
import * as path from 'node:path'
import { pathToFileURL } from 'node:url'
import { getTsconfig } from 'get-tsconfig'
import MagicString from 'magic-string'
import { minify } from 'oxc-minify'
import { parseSync, visitorKeys } from 'oxc-parser'
import { transform as oxcTransform } from 'oxc-transform'
import { init as esModuleLexerInit, parse as esModuleLexer } from 'es-module-lexer'
import type { Cache, TsConfigJsonResolved } from 'get-tsconfig'
import type { Node, Program } from 'oxc-parser'
import type { TransformOptions as OxcTransformOptions } from 'oxc-transform'

import { isCommonJS, mayContainCommonJSModuleGlobals } from './cjs-check.ts'
import {
  createAssetServerCompilationError,
  isAssetServerCompilationError,
} from '../compilation-error.ts'
import type { AssetServerCompilationError } from '../compilation-error.ts'
import {
  maskAuthoredInjectedPackageSpecifier,
  mayContainInjectedPackageSpecifier,
  restoreAuthoredInjectedPackageSpecifier,
} from '../injected-packages.ts'
import type { ModuleRecord, ModuleTracking } from '../module-store.ts'
import type {
  ModuleLoadContext,
  ModuleLoader,
  ModuleLoadResult,
  NextModuleLoader,
} from '../loaders.ts'
import { normalizeFilePath } from '../paths.ts'
import type { CompiledRoutes } from '../routes.ts'
import { composeSourceMaps, rewriteSourceMapSources, stringifySourceMap } from '../source-maps.ts'
import type { EmittedModule } from './emit.ts'
import type { ResolvedScriptTarget } from '../target.ts'
import type { ResolvedModule } from './resolve.ts'
import { scriptLoaderConditions } from './conditions.ts'
import { isBareImportSpecifier } from './specifiers.ts'

type ScriptRecord = ModuleRecord<TransformedModule, ResolvedModule, EmittedModule>

type SourceLanguage = 'js' | 'jsx' | 'ts' | 'tsx'
type ModuleLoadSource = NonNullable<ModuleLoadResult['source']>

const scriptModuleTypes = [
  { extension: '.js', lang: 'js' },
  { extension: '.jsx', lang: 'jsx' },
  { extension: '.mjs', lang: 'js' },
  { extension: '.mts', lang: 'ts' },
  { extension: '.ts', lang: 'ts' },
  { extension: '.tsx', lang: 'tsx' },
] as const satisfies ReadonlyArray<{ extension: string; lang: SourceLanguage }>

const sourceLanguageByExtension = new Map<string, SourceLanguage>(
  scriptModuleTypes.map(({ extension, lang }) => [extension, lang] as const),
)

const supportedTsconfigTransformCompilerOptions = {
  allowNamespaces: 'allowNamespaces',
  emitDecoratorMetadata: 'emitDecoratorMetadata',
  experimentalDecorators: 'experimentalDecorators',
  jsx: 'jsx',
  jsxFactory: 'jsxFactory',
  jsxFragmentFactory: 'jsxFragmentFactory',
  jsxImportSource: 'jsxImportSource',
  useDefineForClassFields: 'useDefineForClassFields',
} as const

export type ResolveModuleResult = {
  identityPath: string
  resolvedPath: string
}

type UnresolvedImport = {
  dynamic: boolean
  end: number
  quote?: '"' | "'" | '`'
  specifier: string
  start: number
}

type HmrAcceptedDependency = Omit<UnresolvedImport, 'dynamic'>

export type TransformedModule = {
  hmr: {
    acceptedDeps: HmrAcceptedDependency[]
    selfAccepting: boolean
    usesImportMetaHot: boolean
  }
  identityPath: string
  importerDir: string
  packageSpecifiers: string[]
  rawCode: string
  resolvedPath: string
  sourceMap: string | null
  stableUrlPathname: string
  trackedFiles: string[]
  unresolvedImports: UnresolvedImport[]
}

type TransformResult = {
  tracking: ModuleTracking
} & (
  | {
      ok: true
      value: TransformedModule
    }
  | {
      ok: false
      error: AssetServerCompilationError
    }
)

type TsconfigTransformOptions = {
  trackedFiles: string[]
  tsconfigRaw?: TsConfigJsonResolved
}

type TsconfigTransformOptionsResolver = ReturnType<typeof createTsconfigTransformOptionsResolver>

export type TransformArgs = {
  define: Record<string, string> | null
  externalSet: ReadonlySet<string>
  isWatchIgnored(filePath: string): boolean
  minify: boolean
  loaders: readonly ModuleLoader[]
  resolveActualPath(identityPath: string): string | null
  routes: CompiledRoutes
  sourceMapSourcePaths: 'absolute' | 'url'
  sourceMaps: 'external' | 'inline' | null
  target: ResolvedScriptTarget | null
  tsconfigTransformOptionsResolver: TsconfigTransformOptionsResolver
}

export function createTsconfigTransformOptionsResolver() {
  let fileSystemCache: Cache = new Map()
  let transformOptionsByDirectory = new Map<string, TsconfigTransformOptions>()

  return {
    clear() {
      fileSystemCache = new Map()
      transformOptionsByDirectory.clear()
    },
    getTransformOptions(
      filePath: string,
      isWatchIgnored: (filePath: string) => boolean,
    ): TsconfigTransformOptions {
      let directory = path.dirname(filePath)
      let cached = transformOptionsByDirectory.get(directory)
      if (cached) return cached

      let tsconfig = getTsconfig(directory, 'tsconfig.json', fileSystemCache)
      if (!tsconfig) {
        let transformOptions = { trackedFiles: [] }
        transformOptionsByDirectory.set(directory, transformOptions)
        return transformOptions
      }

      let tsconfigPath = findNearestTsconfigPath(directory)
      let transformOptions: TsconfigTransformOptions = {
        trackedFiles: tsconfigPath && !isWatchIgnored(tsconfigPath) ? [tsconfigPath] : [],
        tsconfigRaw: tsconfig.config,
      }

      transformOptionsByDirectory.set(directory, transformOptions)
      return transformOptions
    },
  }
}

export async function transformModule(
  record: ScriptRecord,
  args: TransformArgs,
): Promise<TransformResult> {
  let resolvedPath = args.resolveActualPath(record.identityPath)
  if (!resolvedPath) {
    return {
      ok: false,
      error: createAssetServerCompilationError(`File not found: ${record.identityPath}`, {
        code: 'FILE_NOT_FOUND',
      }),
      tracking: {
        trackedFiles: args.isWatchIgnored(record.identityPath) ? [] : [record.identityPath],
      },
    }
  }

  let transformOptions = args.tsconfigTransformOptionsResolver.getTransformOptions(
    resolvedPath,
    args.isWatchIgnored,
  )
  let trackedFiles = [
    ...(args.isWatchIgnored(resolvedPath) ? [] : [resolvedPath]),
    ...transformOptions.trackedFiles,
  ]
  let sourceText: string
  try {
    sourceText = await fsp.readFile(resolvedPath, 'utf-8')
  } catch (error) {
    if (isNoEntityError(error)) {
      return {
        ok: false,
        error: createAssetServerCompilationError(`File not found: ${resolvedPath}`, {
          cause: error,
          code: 'FILE_NOT_FOUND',
        }),
        tracking: {
          trackedFiles,
        },
      }
    }
    return {
      ok: false,
      error: toTransformFailedError(error, resolvedPath),
      tracking: {
        trackedFiles,
      },
    }
  }

  try {
    let stableUrlPathname = args.routes.toUrlPathname(record.identityPath)
    if (!stableUrlPathname) {
      throw createAssetServerCompilationError(
        `File ${record.identityPath} is outside all configured mounts.`,
        {
          code: 'FILE_OUTSIDE_MOUNTS',
        },
      )
    }

    let analysis = await analyzeModuleSource(sourceText, resolvedPath, transformOptions, {
      define: args.define ?? undefined,
      minify: args.minify,
      loaders: args.loaders,
      moduleUrl: stableUrlPathname,
      sourceMaps: args.sourceMaps ?? undefined,
      target: args.target ?? undefined,
    })

    analysis.unresolvedImports = analysis.unresolvedImports.filter(
      (unresolved) => !args.externalSet.has(getDisplayImportSpecifier(unresolved.specifier)),
    )

    if (mayContainCommonJSModuleGlobals(sourceText) && isCommonJS(analysis.rawCode)) {
      throw createAssetServerCompilationError(
        `CommonJS module detected: ${resolvedPath}. ` +
          `This module uses CommonJS (require/module.exports) which is not supported. ` +
          `Please use an ESM-compatible module.`,
        {
          code: 'COMMONJS_NOT_SUPPORTED',
        },
      )
    }

    let sourceMap = analysis.sourceMap
      ? rewriteSourceMapSources(
          analysis.sourceMap,
          resolvedPath,
          stableUrlPathname,
          args.sourceMapSourcePaths,
          sourceText,
        )
      : null

    return {
      ok: true,
      tracking: {
        trackedFiles,
      },
      value: {
        hmr: getHmrAnalysis(analysis.rawCode),
        identityPath: record.identityPath,
        importerDir: path.dirname(resolvedPath),
        packageSpecifiers: analysis.unresolvedImports
          .filter((unresolved) => isBareImportSpecifier(unresolved.specifier))
          .map((unresolved) => unresolved.specifier),
        rawCode: analysis.rawCode,
        resolvedPath,
        sourceMap,
        stableUrlPathname,
        trackedFiles,
        unresolvedImports: analysis.unresolvedImports,
      },
    }
  } catch (error) {
    return {
      ok: false,
      error: toTransformFailedError(error, resolvedPath),
      tracking: {
        trackedFiles,
      },
    }
  }
}

export function getHmrAnalysis(rawCode: string): TransformedModule['hmr'] {
  let mayUseImportMetaHot = rawCode.includes('import.meta.hot')
  let usesImportMetaHot = false
  let acceptedDeps: HmrAcceptedDependency[] = []
  let selfAccepting = false

  if (mayUseImportMetaHot) {
    try {
      let parseResult = parseSync('hmr-analysis.js', rawCode, {
        lang: 'js',
        sourceType: 'module',
      })

      if (parseResult.errors.length > 0) {
        throw createAssetServerCompilationError(
          `Failed to analyze HMR usage in transformed script. ${parseResult.errors[0]?.message ?? 'Unknown parse error'}`,
          {
            code: 'TRANSFORM_FAILED',
          },
        )
      }

      walkAst(parseResult.program, (node) => {
        if (isImportMetaHotNode(node)) {
          usesImportMetaHot = true
        }

        if (node.type !== 'CallExpression') return
        if (!isImportMetaHotAcceptCallee(node.callee)) return

        let [firstArgument] = node.arguments
        if (firstArgument === undefined || !isAcceptedDependencyArgument(firstArgument)) {
          selfAccepting = true
          return
        }

        acceptedDeps.push(...getAcceptedDependencies(firstArgument, rawCode))
      })
    } catch (error) {
      if (isAssetServerCompilationError(error)) throw error
      throw createAssetServerCompilationError(
        `Failed to analyze HMR usage in transformed script.`,
        {
          cause: error,
          code: 'TRANSFORM_FAILED',
        },
      )
    }
  }

  return {
    acceptedDeps,
    selfAccepting,
    usesImportMetaHot,
  }
}

function isImportMetaHotAcceptCallee(node: Node): boolean {
  let callee = unwrapChainExpression(node)
  if (callee.type !== 'MemberExpression') return false
  if (callee.computed || !isIdentifierNode(callee.property, 'accept')) return false

  return isImportMetaHotNode(callee.object)
}

function isImportMetaHotNode(node: Node): boolean {
  let hot = unwrapChainExpression(node)
  if (hot.type !== 'MemberExpression') return false
  if (hot.computed || !isIdentifierNode(hot.property, 'hot')) return false

  let meta = unwrapChainExpression(hot.object)
  return (
    meta.type === 'MetaProperty' &&
    isIdentifierNode(meta.meta, 'import') &&
    isIdentifierNode(meta.property, 'meta')
  )
}

function unwrapChainExpression(node: Node): Node {
  return node.type === 'ChainExpression' ? node.expression : node
}

function isIdentifierNode(node: Node, name: string): boolean {
  return node.type === 'Identifier' && node.name === name
}

function isAcceptedDependencyArgument(node: Node): boolean {
  return isStringLiteralNode(node) || node.type === 'ArrayExpression'
}

function getAcceptedDependencies(node: Node, source: string): HmrAcceptedDependency[] {
  if (isStringLiteralNode(node)) {
    return [
      {
        end: node.end - 1,
        specifier: node.value,
        start: node.start + 1,
      },
    ]
  }

  if (node.type !== 'ArrayExpression') return []

  let deps: HmrAcceptedDependency[] = []
  for (let element of node.elements) {
    if (!isStringLiteralNode(element)) continue
    deps.push({
      end: element.end - 1,
      specifier: element.value,
      start: element.start + 1,
    })
  }
  return deps
}

function findNearestTsconfigPath(directory: string): string | null {
  let currentDirectory = directory

  while (true) {
    let tsconfigPath = path.join(currentDirectory, 'tsconfig.json')
    if (fs.existsSync(tsconfigPath)) {
      return normalizeFilePath(tsconfigPath)
    }

    let parentDirectory = path.dirname(currentDirectory)
    if (parentDirectory === currentDirectory) return null
    currentDirectory = parentDirectory
  }
}

async function analyzeModuleSource(
  sourceText: string,
  resolvedPath: string,
  transformOptions: TsconfigTransformOptions,
  options: {
    define?: Record<string, string>
    minify: boolean
    loaders: readonly ModuleLoader[]
    moduleUrl: string
    sourceMaps?: 'external' | 'inline'
    target?: ResolvedScriptTarget
  },
) {
  let maskedSourceText = maskAuthoredInjectedPackageImports(sourceText, resolvedPath)
  let transformResult: { code: string; errors?: Array<{ message?: string }>; map?: unknown }
  try {
    transformResult = await oxcTransform(
      resolvedPath,
      maskedSourceText,
      getTransformOptions(resolvedPath, transformOptions, options),
    )
    assertNoCompilerErrors(transformResult.errors, resolvedPath, 'transform')
  } catch (error) {
    if (isAssetServerCompilationError(error)) throw error
    throw createAssetServerCompilationError(
      `Failed to transform script ${resolvedPath}. ${formatUnknownError(error)}`,
      {
        cause: error,
        code: 'TRANSFORM_FAILED',
      },
    )
  }

  let rawCode = transformResult.code.trimEnd()
  let sourceMap = stringifySourceMap(transformResult.map)

  if (options.loaders.length > 0) {
    let loaderUrl = pathToFileURL(resolvedPath).href
    let loaderInputSource = sourceMap ? appendInlineSourceMap(rawCode, sourceMap) : rawCode
    let loaderOutputSource: string
    try {
      let loaderResult = runModuleLoaders(loaderUrl, {
        format: 'module',
        loaders: options.loaders,
        moduleUrl: options.moduleUrl,
        source: loaderInputSource,
      })
      loaderOutputSource = moduleLoadSourceToString(getModuleLoadSource(loaderUrl, loaderResult))
    } catch (error) {
      if (isAssetServerCompilationError(error)) throw error
      throw createAssetServerCompilationError(
        `Module loader failed for ${loaderUrl}. ${formatUnknownError(error)}`,
        {
          cause: error,
          code: 'LOADER_FAILED',
        },
      )
    }
    if (loaderOutputSource !== loaderInputSource) {
      let loaderOutput = extractInlineSourceMap(loaderOutputSource)
      rawCode = loaderOutput.code.trimEnd()
      sourceMap =
        loaderOutput.sourceMap && loaderOutput.sourceMap !== sourceMap
          ? sourceMap
            ? composeSourceMaps(loaderOutput.sourceMap, sourceMap)
            : loaderOutput.sourceMap
          : null
    }
  }

  if (options.minify) {
    let minifyResult = await minifyModule(rawCode, resolvedPath, options.target, options.sourceMaps)
    rawCode = minifyResult.code.trimEnd()
    let minifyMap = stringifySourceMap(minifyResult.map)
    sourceMap =
      minifyMap == null
        ? sourceMap
        : sourceMap == null
          ? minifyMap
          : composeSourceMaps(minifyMap, sourceMap)
  }

  return {
    rawCode,
    sourceMap,
    unresolvedImports: await getUnresolvedImportsFromLexer(rawCode),
  }
}

function runModuleLoaders(
  url: string,
  options: {
    format: string
    loaders: readonly ModuleLoader[]
    moduleUrl: string
    source: string
  },
): ModuleLoadResult {
  let loadContext: ModuleLoadContext = {
    conditions: [...scriptLoaderConditions],
    format: options.format,
    importAttributes: {},
    moduleUrl: options.moduleUrl,
  }

  let load: NextModuleLoader = (_url, context) => ({
    format: context?.format ?? options.format,
    source: options.source,
  })

  for (let loader of options.loaders) {
    let nextLoad = load
    load = (nextUrl, nextContext) => {
      let nextLoadCalled = false
      let wrappedNextLoad: NextModuleLoader = (wrappedUrl, wrappedContext) => {
        if (wrappedUrl !== nextUrl) {
          throw createAssetServerCompilationError(
            `Module loader for ${nextUrl} attempted to change the module URL to ${wrappedUrl}. Loaders cannot change module URLs.`,
            {
              code: 'LOADER_FAILED',
            },
          )
        }
        nextLoadCalled = true
        return nextLoad(wrappedUrl, wrappedContext)
      }
      let result = loader(
        nextUrl,
        {
          conditions: nextContext?.conditions ?? loadContext.conditions,
          format: nextContext?.format ?? loadContext.format,
          importAttributes: nextContext?.importAttributes ?? loadContext.importAttributes,
          moduleUrl: nextContext?.moduleUrl ?? loadContext.moduleUrl,
        },
        wrappedNextLoad,
      )
      if (!nextLoadCalled && result.shortCircuit !== true) {
        throw createAssetServerCompilationError(
          `Module loader for ${nextUrl} returned without calling nextLoad or setting shortCircuit: true.`,
          {
            code: 'LOADER_FAILED',
          },
        )
      }
      return result
    }
  }

  return load(url, loadContext)
}

function getModuleLoadSource(url: string, result: ModuleLoadResult): ModuleLoadSource {
  if (result.format !== 'module') {
    throw createAssetServerCompilationError(
      `Module loader for ${url} returned unsupported format ${JSON.stringify(result.format)}. Only "module" is supported.`,
      {
        code: 'LOADER_FAILED',
      },
    )
  }

  if (result.source !== undefined && result.source !== null) return result.source

  throw createAssetServerCompilationError(`Module loader for ${url} did not return source.`, {
    code: 'LOADER_FAILED',
  })
}

function moduleLoadSourceToString(source: ModuleLoadSource): string {
  if (typeof source === 'string') return source
  return new TextDecoder().decode(source)
}

function appendInlineSourceMap(source: string, sourceMap: string): string {
  let encoded = Buffer.from(sourceMap).toString('base64')
  return `${source}\n//# sourceMappingURL=data:application/json;base64,${encoded}`
}

function extractInlineSourceMap(source: string): {
  code: string
  sourceMap: string | null
} {
  let sourceMapPattern =
    /(?:\/\/# sourceMappingURL=data:application\/json;base64,([A-Za-z0-9+/=]+)|\/\*# sourceMappingURL=data:application\/json;base64,([A-Za-z0-9+/=]+) \*\/)\s*$/g
  let sourceMap: string | null = null
  let code = source.replace(sourceMapPattern, (_match, lineComment, blockComment) => {
    sourceMap = Buffer.from(lineComment ?? blockComment, 'base64').toString('utf-8')
    return ''
  })

  return { code, sourceMap }
}

async function minifyModule(
  rawCode: string,
  resolvedPath: string,
  target: ResolvedScriptTarget | undefined,
  sourceMaps?: 'external' | 'inline',
) {
  try {
    let result = await minify(resolvedPath, rawCode, {
      compress: target ? { target } : true,
      mangle: true,
      module: true,
      sourcemap: sourceMaps != null,
    })
    assertNoCompilerErrors(result.errors, resolvedPath, 'minify')
    return result
  } catch (error) {
    if (isAssetServerCompilationError(error)) throw error
    throw createAssetServerCompilationError(
      `Failed to minify script ${resolvedPath}. ${formatUnknownError(error)}`,
      {
        cause: error,
        code: 'TRANSFORM_FAILED',
      },
    )
  }
}

function getTransformOptions(
  resolvedPath: string,
  transformOptions: TsconfigTransformOptions,
  options: {
    define?: Record<string, string>
    sourceMaps?: 'external' | 'inline'
    target?: ResolvedScriptTarget
  },
): OxcTransformOptions {
  let compilerOptions = transformOptions.tsconfigRaw?.compilerOptions as
    | Record<string, unknown>
    | undefined
  let useDefineForClassFields = getBooleanOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.useDefineForClassFields,
  )
  let jsxFactory = getStringOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.jsxFactory,
  )
  let jsxFragmentFactory = getStringOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.jsxFragmentFactory,
  )

  return {
    assumptions:
      useDefineForClassFields === false
        ? {
            setPublicClassFields: true,
          }
        : undefined,
    decorator: getDecoratorOptions(compilerOptions),
    define: options.define,
    jsx: getJsxOptions(resolvedPath, compilerOptions),
    lang: getSourceLanguageForPath(resolvedPath),
    sourceType: 'module' as const,
    sourcemap: options.sourceMaps != null,
    target: options.target,
    typescript: {
      allowNamespaces: getBooleanOption(
        compilerOptions,
        supportedTsconfigTransformCompilerOptions.allowNamespaces,
      ),
      jsxPragma: jsxFactory,
      jsxPragmaFrag: jsxFragmentFactory,
      removeClassFieldsWithoutInitializer: useDefineForClassFields === false ? true : undefined,
    },
  }
}

function getJsxOptions(
  resolvedPath: string,
  compilerOptions?: Record<string, unknown>,
): OxcTransformOptions['jsx'] | undefined {
  let language = getSourceLanguageForPath(resolvedPath)
  if (language !== 'jsx' && language !== 'tsx') return undefined

  let jsx = getStringOption(compilerOptions, supportedTsconfigTransformCompilerOptions.jsx)
  let importSource = getStringOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.jsxImportSource,
  )
  let pragma = getStringOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.jsxFactory,
  )
  let pragmaFrag = getStringOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.jsxFragmentFactory,
  )

  if (jsx === 'preserve' || jsx === 'react-native') {
    throw createAssetServerCompilationError(
      `Unsupported tsconfig compilerOptions.jsx = "${jsx}" for ${resolvedPath}. ` +
        `Asset server must compile JSX to browser-runnable JavaScript.`,
      {
        code: 'TRANSFORM_FAILED',
      },
    )
  }

  if (jsx === 'react-jsx' || jsx === 'react-jsxdev') {
    return {
      development: jsx === 'react-jsxdev',
      importSource,
      runtime: 'automatic',
    }
  }

  return {
    pragma,
    pragmaFrag,
    runtime: 'classic',
  }
}

function getDecoratorOptions(
  compilerOptions?: Record<string, unknown>,
): OxcTransformOptions['decorator'] | undefined {
  let legacy = getBooleanOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.experimentalDecorators,
  )
  let emitDecoratorMetadata = getBooleanOption(
    compilerOptions,
    supportedTsconfigTransformCompilerOptions.emitDecoratorMetadata,
  )

  if (legacy !== true && emitDecoratorMetadata !== true) return undefined

  return {
    emitDecoratorMetadata,
    legacy,
  }
}

function getBooleanOption(
  compilerOptions: Record<string, unknown> | undefined,
  key: string,
): boolean | undefined {
  let value = compilerOptions?.[key]
  return typeof value === 'boolean' ? value : undefined
}

function getStringOption(
  compilerOptions: Record<string, unknown> | undefined,
  key: string,
): string | undefined {
  let value = compilerOptions?.[key]
  return typeof value === 'string' ? value : undefined
}

function assertNoCompilerErrors(
  errors: Array<{ message?: string }> | undefined,
  resolvedPath: string,
  operation: 'transform' | 'minify',
) {
  if (!errors || errors.length === 0) return

  throw createAssetServerCompilationError(
    `Failed to ${operation} script ${resolvedPath}. ${errors[0].message ?? 'Unknown error'}`,
    {
      code: 'TRANSFORM_FAILED',
    },
  )
}

async function getUnresolvedImportsFromLexer(rawCode: string): Promise<UnresolvedImport[]> {
  await esModuleLexerInit
  let [imports] = esModuleLexer(rawCode)
  let unresolvedImports: UnresolvedImport[] = []

  for (let imported of imports) {
    let specifier = getStaticImportSpecifier(rawCode, imported)
    if (specifier == null || isBrowserExternalModuleUrl(specifier)) continue
    unresolvedImports.push({
      dynamic: imported.d !== -1,
      specifier,
      start: imported.s,
      end: imported.e,
      quote: getImportQuote(rawCode, imported.s),
    })
  }

  return unresolvedImports
}

function getDisplayImportSpecifier(specifier: string): string {
  return restoreAuthoredInjectedPackageSpecifier(specifier) ?? specifier
}

function isBrowserExternalModuleUrl(url: string): boolean {
  return url.startsWith('data:') || url.startsWith('http://') || url.startsWith('https://')
}

function maskAuthoredInjectedPackageImports(sourceText: string, resolvedPath: string): string {
  if (!mayContainInjectedPackageSpecifier(sourceText)) {
    return sourceText
  }

  let parseResult = parseSync(resolvedPath, sourceText, {
    lang: getSourceLanguageForPath(resolvedPath),
    sourceType: 'module',
  })
  if (parseResult.errors.length > 0) {
    return sourceText
  }

  let replacements: Array<{ end: number; specifier: string; start: number }> = []

  walkAst(parseResult.program, (node) => {
    if (
      node.type !== 'ImportDeclaration' &&
      node.type !== 'ExportAllDeclaration' &&
      node.type !== 'ExportNamedDeclaration' &&
      node.type !== 'ImportExpression'
    ) {
      return
    }

    let source = 'source' in node ? node.source : null
    if (!isStringLiteralNode(source)) return

    let maskedSpecifier = maskAuthoredInjectedPackageSpecifier(source.value)
    if (maskedSpecifier == null) return

    replacements.push({
      end: source.end - 1,
      specifier: maskedSpecifier,
      start: source.start + 1,
    })
  })

  if (replacements.length === 0) return sourceText

  let rewrittenSource = new MagicString(sourceText)
  for (let replacement of replacements) {
    rewrittenSource.overwrite(replacement.start, replacement.end, replacement.specifier)
  }

  return rewrittenSource.toString()
}

function walkAst(node: Program | Node, visit: (node: Program | Node) => void): void {
  visit(node)

  let keys = visitorKeys[node.type]
  if (!keys) return

  let walkableNode = node as unknown as Record<string, unknown>
  for (let key of keys) {
    let value = walkableNode[key]
    if (Array.isArray(value)) {
      for (let child of value) {
        if (isAstNode(child)) {
          walkAst(child, visit)
        }
      }
      continue
    }

    if (isAstNode(value)) {
      walkAst(value, visit)
    }
  }
}

function isAstNode(value: unknown): value is Node {
  return typeof value === 'object' && value !== null && 'type' in value
}

function isStringLiteralNode(node: Node | null | undefined): node is Node & {
  end: number
  start: number
  value: string
} {
  return (
    node?.type === 'Literal' &&
    typeof node.start === 'number' &&
    typeof node.end === 'number' &&
    typeof node.value === 'string'
  )
}

function getStaticImportSpecifier(
  source: string,
  imported: ReturnType<typeof esModuleLexer>[0][number],
): string | null {
  if (imported.n != null) {
    return imported.n
  }

  if (imported.d < 0) {
    return null
  }

  let rawSpecifier = source.slice(imported.s, imported.e)
  if (!isStaticTemplateLiteral(rawSpecifier)) {
    return null
  }

  return rawSpecifier.slice(1, -1)
}

function isStaticTemplateLiteral(specifier: string): boolean {
  return specifier.startsWith('`') && specifier.endsWith('`') && !specifier.includes('${')
}

function getImportQuote(source: string, start: number): '"' | "'" | '`' | undefined {
  let firstCharacter = source[start]
  if (firstCharacter === '"' || firstCharacter === "'" || firstCharacter === '`') {
    return firstCharacter
  }
  return undefined
}

function getSourceLanguageForPath(resolvedPath: string): SourceLanguage {
  let extension = path.extname(resolvedPath).toLowerCase()
  return sourceLanguageByExtension.get(extension) ?? 'js'
}

function formatUnknownError(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function toTransformFailedError(error: unknown, resolvedPath: string): AssetServerCompilationError {
  if (isAssetServerCompilationError(error)) return error

  return createAssetServerCompilationError(
    `Failed to transform script ${resolvedPath}. ${formatUnknownError(error)}`,
    {
      cause: error,
      code: 'TRANSFORM_FAILED',
    },
  )
}

function isNoEntityError(error: unknown): error is NodeJS.ErrnoException & { code: 'ENOENT' } {
  return (
    error instanceof Error && 'code' in error && (error as NodeJS.ErrnoException).code === 'ENOENT'
  )
}
