import * as path from 'node:path'
import * as fs from 'node:fs'
import { createAccessPolicy } from './access.ts'
import {
  createAssetServerCompilationError,
  isAssetServerCompilationError,
} from './compilation-error.ts'
import { createFileCompiler, createResponseForFile } from './files/compiler.ts'
import type { FileCompiler } from './files/compiler.ts'
import { normalizeFilesOptions, serializeAssetTransformInvocations } from './files/config.ts'
import type {
  AssetRequestTransformMap,
  AssetServerFilesOptions,
  AssetTransformInvocation,
  ResolvedAssetServerFilesOptions,
} from './files/config.ts'
import { getFingerprintRequestCacheControl, parseFingerprintSuffix } from './fingerprint.ts'
import { createHmrClientSource } from './hmr.ts'
import type { HmrPayload } from './hmr.ts'
import { getInjectedPackageMountConfigs } from './injected-packages.ts'
import type { ModuleLoader } from './loaders.ts'
import { normalizeFilePath, normalizePathname } from './paths.ts'
import { compileRoutes } from './routes.ts'
import type { CompiledRoutes } from './routes.ts'
import { createResponseForScript, createScriptCompiler } from './scripts/compiler.ts'
import type { ScriptHmrUpdate, ScriptImportMap } from './scripts/compiler.ts'
import { supportedScriptExtensions } from './scripts/resolve.ts'
import { createResponseForStyle, createStyleCompiler, isStyleFilePath } from './styles/compiler.ts'
import { resolveScriptTarget, resolveStyleTarget } from './target.ts'
import type { AssetTarget, ResolvedScriptTarget, ResolvedStyleTarget } from './target.ts'
import { createAssetServerWatcher } from './watch.ts'
import { createAssetInspector, type AssetDetails } from './inspection.ts'
import type { AssetServerWatcher, ChokidarWatcher } from './watch.ts'
import { getVirtualStoreMountConfigs } from './virtual-store.ts'

interface AssetServerWatchOptions {
  /**
   * Ignore matching glob patterns or file paths. Relative values are resolved
   * from `rootDir`.
   */
  ignore?: readonly string[]
  /**
   * Use polling instead of native filesystem events. Defaults to `false`.
   */
  poll?: boolean
  /**
   * Polling interval in milliseconds when `poll` is enabled. Defaults to `100`.
   */
  pollInterval?: number
}

/**
 * Bridge used by an asset server to watch browser source files and publish update events through a
 * server-level HMR runtime.
 *
 * The asset server registers its file handler, keeps the channel's watched-file set in sync with
 * compiled assets, injects `url` into its browser HMR client, and closes the channel when the asset
 * server closes.
 */
export interface BrowserHmrChannel {
  /** Absolute EventSource URL that receives the browser HMR events produced by this channel. */
  readonly url: string
  /** Releases the channel and all file-watching resources it owns. */
  close(): void
  /**
   * Registers the asset server's handler for file changes reported by the channel's watcher.
   *
   * @param handler Callback that converts a batch of file changes into browser update or reload
   * events.
   * @returns A cleanup function that stops forwarding file changes to this handler.
   */
  onFileEvents(handler: BrowserHmrFileEventHandler): () => void
  /**
   * Applies additions and removals to the channel's set of watched absolute file paths.
   *
   * @param delta Files to add and remove from the watcher.
   */
  updateWatchedFiles(delta: BrowserHmrWatchedFileDelta): void
}

/**
 * Creates the browser HMR channel owned by an asset server instance.
 *
 * Returning `undefined` leaves browser HMR inactive. The asset server invokes this factory once,
 * after construction, and closes a returned channel from `assetServer.close()`.
 *
 * @returns A channel, no channel, or a promise for either result.
 */
export type BrowserHmrChannelFactory = () =>
  | BrowserHmrChannel
  | undefined
  | Promise<BrowserHmrChannel | undefined>

/** Browser HMR integration options. */
export interface BrowserHmrOptions {
  /** Creates the channel that delivers browser HMR events. */
  channel: BrowserHmrChannelFactory
  /**
   * Module specifier resolved relative to the asset server's root directory. It must point to a
   * browser module exporting `importModule(specifier, parentUrl)` for evaluating JavaScript updates.
   * The module and its dependencies must be allowed and reachable through configured mounts.
   */
  moduleImporter?: string
}

/**
 * Converts a watcher batch into ordered browser update or reload events.
 *
 * @param events File additions, changes, and removals reported together by the watcher.
 * @returns Browser events to publish in their returned order.
 */
export type BrowserHmrFileEventHandler = (
  events: readonly BrowserHmrFileEvent[],
) => Promise<readonly BrowserHmrEvent[]>

/**
 * Watched file delta for a browser HMR channel.
 */
export interface BrowserHmrWatchedFileDelta {
  /** Absolute source file paths newly required by the asset server's compiled module graph. */
  add: readonly string[]
  /** Absolute source file paths no longer required by the asset server's compiled module graph. */
  remove: readonly string[]
}

/**
 * File watcher event reported to a browser HMR channel.
 */
export type BrowserHmrFileEvent = {
  /** Filesystem operation observed by the channel's watcher. */
  event: 'add' | 'change' | 'unlink'
  /** Absolute path of the source file that changed. */
  filePath: string
}

/**
 * Browser HMR event emitted to connected clients.
 */
export type BrowserHmrEvent =
  | {
      /** Consumer-owned data keyed by a stable, versioned namespace. */
      data: Record<string, BrowserHmrData>
      /** Absolute source file paths that triggered this update. */
      files?: string[]
      /** Browser update event. */
      type: 'update'
    }
  | {
      /** Absolute source file paths that could not be handled in place. */
      files?: string[]
      /** Browser reload event. */
      type: 'reload'
    }

type AssetSourceMaps = 'inline' | 'external'
type AssetSourceMapSourcePaths = 'url' | 'absolute'
type BrowserHmrData =
  | null
  | boolean
  | number
  | string
  | BrowserHmrData[]
  | { [key: string]: BrowserHmrData }

interface AssetServerScriptOptions {
  /**
   * Replace global expressions with constant values during transform, e.g.
   * `{ 'process.env.NODE_ENV': '"production"' }`
   */
  define?: Record<string, string>
  /** Import specifiers to treat as external dependencies (CDN URLs, import map entries, etc.) */
  external?: string[]
  /**
   * Synchronous loaders that post-process compiled JavaScript.
   *
   * Loaders use Node's synchronous `load` hook signature. Later loaders wrap earlier loaders: for
   * `[first, second]`, `second` is entered first and delegates through `first` to the default
   * behavior. As a result, transformations performed after `nextLoad()` are applied in array order.
   * Loaders run after TypeScript/JavaScript transformation and before HMR analysis and minification.
   * Only `format: 'module'` is supported, and import attributes are unsupported.
   */
  loaders?: readonly ModuleLoader[]
}

const scriptExtensionSet = new Set<string>(supportedScriptExtensions)
const defaultMounts = {
  app: 'app',
  npm: 'node_modules',
} as const

/**
 * Options used to construct an {@link AssetServer} via {@link createAssetServer}.
 */
export interface AssetServerOptions<transforms extends AssetRequestTransformMap = {}> {
  /** Public mount path for this asset server, e.g. `'/assets'`. */
  basePath: string
  /**
   * Directories to mount at public URL paths.
   *
   * Each key is a public URL path and its value is a directory relative to `rootDir`. Defaults to
   * `{ app: 'app', npm: 'node_modules' }`. Public paths must not contain query strings, fragments,
   * or encoded dot segments.
   */
  mounts?: Readonly<Record<string, string>>
  /**
   * Root directory used to resolve relative file paths. Defaults to `process.cwd()`.
   */
  rootDir?: string
  /**
   * Glob patterns or file paths that are allowed to be served. Relative values are resolved from `rootDir`.
   */
  allowFiles: readonly string[]
  /**
   * Exact package names whose files are allowed to be served. Dependencies and installed optional
   * dependencies are allowed automatically. Package files must still be within a configured mount.
   */
  allowPackages?: readonly string[]
  /**
   * Glob patterns or file paths that are denied from being served. Relative values are resolved from `rootDir`.
   */
  denyFiles?: readonly string[]
  /**
   * Controls optional content-based URL fingerprinting for served asset URLs.
   *
   * When omitted, all served assets use stable non-fingerprinted URLs with `Cache-Control: no-cache`.
   * Cannot be used together with active watch mode. Set `watch: false` when fingerprinting.
   */
  fingerprint?: boolean
  /**
   * Shared compatibility target for scripts and styles. Browser targets apply to both
   * pipelines, and `es` only affects scripts.
   */
  target?: AssetTarget
  /**
   * Source map mode for scripts and styles.
   * - `'external'`: serve source maps as separate `.map` files
   * - `'inline'`: embed source maps as a base64 data URL in the compiled asset
   */
  sourceMaps?: AssetSourceMaps
  /**
   * Source path strategy for source map `sources`.
   * - `'url'` (default): use the stable server path (e.g. `'/assets/app/entry.ts'`)
   * - `'absolute'`: use the original filesystem path on disk
   */
  sourceMapSourcePaths?: AssetSourceMapSourcePaths
  /**
   * Minification setting for emitted scripts and styles.
   */
  minify?: boolean
  /**
   * Script-only configuration.
   */
  scripts?: AssetServerScriptOptions
  /**
   * Leaf file asset configuration. Files configured here are served directly and can be
   * referenced from CSS `url(...)` rules. Compiled asset extensions like `.css` and script
   * module extensions are not allowed here.
   */
  files?: AssetServerFilesOptions<transforms>
  /**
   * Enables `import.meta.hot` and coordinates browser updates through a server-level HMR runtime.
   *
   * HMR requires `watch` to be enabled. The factory is called once for this asset server. Returning
   * `undefined` leaves HMR inactive; a returned channel is closed by `assetServer.close()`.
   */
  hmr?: BrowserHmrChannelFactory | BrowserHmrOptions
  /**
   * Enable filesystem-backed cache invalidation for long-lived server instances.
   * Enabled by default. Pass `true` to use the default watcher options, an options
   * object to customize watcher behavior, or `false` to disable watching.
   */
  watch?: boolean | AssetServerWatchOptions
  /**
   * Handles unexpected request-time compilation errors. Return a `Response` to override the
   * default `500 Internal Server Error` response, or return nothing to use the default.
   */
  onError?: (error: unknown) => void | Response | Promise<void | Response>
}

type AssetServerCreateOptions<transforms extends AssetRequestTransformMap> = Omit<
  AssetServerOptions<transforms>,
  'files'
> & {
  files?: Omit<AssetServerFilesOptions<transforms>, 'transforms'> & {
    transforms?: transforms
  }
}

export type AssetServerGetHrefOptions<transforms extends AssetRequestTransformMap> =
  | undefined
  | {
      transform: readonly AssetTransformInvocation<transforms>[]
    }

/**
 * Metadata needed to render or load a script entry module.
 */
export interface ScriptEntry {
  /** Public URL for the script entry module. */
  href: string
  /** Public URLs that should be emitted as `modulepreload` hints for this script graph. */
  preloads: string[]
  /** Import map entries required to resolve this script graph in the browser. */
  importMap: ScriptImportMap
}

/**
 * Serves compiled scripts and styles for asset requests routed to it.
 * Construct with {@link createAssetServer}.
 */
export interface AssetServer<transforms extends AssetRequestTransformMap = {}> {
  /**
   * Serves a script or style request. Returns `Response | null` — null means the request
   * was not handled by this server, letting the router fall through to a 404.
   */
  fetch(request: Request): Promise<Response | null>
  /**
   * Returns the request href for a served asset file.
   */
  getHref(filePath: string, options?: AssetServerGetHrefOptions<transforms>): Promise<string>
  /**
   * Returns the href, preload URLs, and import map for a script entry module.
   *
   * Results are cached until a watched file changes. Each call returns a separate copy.
   */
  getScriptEntry(filePath: string): Promise<ScriptEntry>
  /**
   * Returns preload URLs for one or more served asset files, ordered shallowest-first.
   */
  getPreloads(filePath: string | readonly string[]): Promise<string[]>
  /**
   * Returns an import map for one or more script entry modules.
   */
  getImportMap(filePath: string | readonly string[]): Promise<ScriptImportMap>
  /**
   * Returns diagnostic details about one public asset URL or file path, including the matched mount
   * roots, access rules, file type, and browser-reachability status.
   */
  getAssetDetails(input: string): Promise<AssetDetails>
  /**
   * Returns every file currently reachable through this asset server, sorted by public URL and
   * then absolute file path.
   */
  getAssets(): Promise<AssetDetails[]>
  /**
   * Closes this server's filesystem watcher and browser HMR channel.
   *
   * @returns A promise that resolves after owned development resources have been released.
   */
  close(): Promise<void>
}

type ResolvedAssetServerOptions<transforms extends AssetRequestTransformMap> = {
  allowFiles: readonly string[]
  allowPackages?: readonly string[]
  basePath: string
  define?: Record<string, string>
  denyFiles?: readonly string[]
  external: string[]
  files: ResolvedAssetServerFilesOptions
  fingerprintAssets: boolean
  hmr: BrowserHmrChannelFactory | null
  hmrModuleImporter: string | null
  minify: boolean
  loaders: readonly ModuleLoader[]
  onError: NonNullable<AssetServerOptions['onError']>
  rootDir: string
  mounts: Readonly<Record<string, string>>
  routes: CompiledRoutes
  sourceMapSourcePaths: 'url' | 'absolute'
  sourceMaps?: 'inline' | 'external'
  scriptsTarget?: ResolvedScriptTarget
  stylesTarget?: ResolvedStyleTarget
  watchOptions: AssetServerWatchOptions | null
}

const chokidarWatcherByAssetServer = new WeakMap<object, ChokidarWatcher>()
const watcherByAssetServer = new WeakMap<object, AssetServerWatcher>()

export function getInternalChokidarWatcher<transforms extends AssetRequestTransformMap>(
  assetServer: AssetServer<transforms>,
): ChokidarWatcher | undefined {
  return chokidarWatcherByAssetServer.get(assetServer)
}

export function getInternalWatchTargets<transforms extends AssetRequestTransformMap>(
  assetServer: AssetServer<transforms>,
): readonly string[] {
  return watcherByAssetServer.get(assetServer)?.getWatchedTargets() ?? []
}

/**
 * Create an asset server instance
 *
 * Compiles TypeScript/JavaScript scripts and CSS styles on demand with optional
 * content-based URL fingerprinting, caching, and configurable directory mounts.
 *
 * @param options Server configuration
 * @returns A {@link AssetServer} with `fetch()`, `getHref()`, and `getPreloads()` methods
 *
 * @example
 * ```ts
 * let assetServer = createAssetServer({
 *   basePath: '/assets',
 *   allowFiles: ['app/routes.ts', 'app/**\/public/**'],
 *   allowPackages: ['remix'],
 *   denyFiles: ['app/**\/*.test.*'],
 * })
 *
 * route('/assets/*path', ({ request }) => assetServer.fetch(request))
 * ```
 */
export function createAssetServer<const transforms extends AssetRequestTransformMap = {}>(
  options: AssetServerCreateOptions<transforms>,
): AssetServer<transforms> {
  let resolvedOptions = resolveAssetServerOptions(options)
  let accessPolicy = createAccessPolicy({
    allowFiles: resolvedOptions.allowFiles,
    allowPackages: resolvedOptions.allowPackages,
    denyFiles: resolvedOptions.denyFiles,
    packageSearchRoots: hasPackages(resolvedOptions.allowPackages)
      ? getPackageSearchRoots(resolvedOptions.mounts, resolvedOptions.rootDir)
      : undefined,
    rootDir: resolvedOptions.rootDir,
  })
  let assetInspector = createAssetInspector({
    accessPolicy,
    allowFiles: resolvedOptions.allowFiles,
    fileExtensions: resolvedOptions.files.extensions,
    rootDir: resolvedOptions.rootDir,
    routes: resolvedOptions.routes,
  })
  let watcher: AssetServerWatcher | null = null
  let scriptEntries = new Map<string, Promise<ScriptEntry>>()
  let chokidarWatcher: ChokidarWatcher | null = null
  let fileCompiler: FileCompiler | null = null
  let closed = false
  let unsubscribeBrowserHmrFileEvents: (() => void) | undefined
  let browserHmrChannelPromise = createBrowserHmrChannel(
    resolvedOptions.hmr,
    handleBrowserHmrFileEvents,
    () => closed,
    (unsubscribe) => {
      unsubscribeBrowserHmrFileEvents = unsubscribe
    },
  )
  void browserHmrChannelPromise.catch(() => {
    // The HMR client request and close() both await this promise. Attach a
    // rejection handler now so async factory failures do not surface first as
    // unhandled rejections.
  })
  let sendHmrPayload = resolvedOptions.hmr ? createHmrPayloadSender() : null
  let hmrPathnames = getHmrPathnames(resolvedOptions.basePath)
  let hmrDataKey = `remix/assets@1:${resolvedOptions.basePath}`
  let scriptCompiler = createScriptCompiler({
    define: resolvedOptions.define,
    external: resolvedOptions.external,
    fingerprintAssets: resolvedOptions.fingerprintAssets,
    loaders: resolvedOptions.loaders,
    hmr: sendHmrPayload
      ? {
          clientPathname: hmrPathnames.client,
          send(updates) {
            let payload = createScriptHmrPayload(updates)
            if (payload) sendHmrPayload(payload)
          },
        }
      : undefined,
    isAllowed: accessPolicy.isAllowed,
    minify: resolvedOptions.minify,
    onWatchDirectoriesChange: (delta) => {
      if (!watcher) return
      watcher.updateWatchedDirectories(delta)
    },
    onWatchFilesChange: (delta) => {
      updateBrowserHmrWatchedFiles(delta)
    },
    rootDir: resolvedOptions.rootDir,
    routes: resolvedOptions.routes,
    sourceMapSourcePaths: resolvedOptions.sourceMapSourcePaths,
    sourceMaps: resolvedOptions.sourceMaps,
    target: resolvedOptions.scriptsTarget,
    watchIgnore: resolvedOptions.watchOptions?.ignore,
    watchMode: resolvedOptions.watchOptions !== null,
  })
  let styleCompiler = createStyleCompiler({
    fingerprintAssets: resolvedOptions.fingerprintAssets,
    getServedFileUrl: (identityPath: string, options: { transform: readonly string[] | null }) => {
      if (!fileCompiler) {
        throw createAssetServerCompilationError(`File type is not supported: ${identityPath}`, {
          code: 'FILE_NOT_SUPPORTED',
        })
      }

      if (options.transform !== null) {
        fileCompiler.validateTransformQuery(options.transform)
      }

      return fileCompiler.getHref(identityPath, { transform: options.transform })
    },
    hmr: sendHmrPayload
      ? {
          send(pathname, timestamp) {
            sendHmrPayload({
              timestamp,
              type: 'browser:update',
              updates: [
                {
                  path: pathname,
                  type: 'css',
                },
              ],
            })
          },
        }
      : undefined,
    isAllowed: accessPolicy.isAllowed,
    isServedFilePath(filePath) {
      return fileCompiler?.isServedFilePath(filePath) ?? false
    },
    minify: resolvedOptions.minify,
    onWatchDirectoriesChange: (delta) => {
      if (!watcher) return
      watcher.updateWatchedDirectories(delta, { includeAncestors: false })
    },
    onWatchFilesChange: (delta) => {
      updateBrowserHmrWatchedFiles(delta)
    },
    rootDir: resolvedOptions.rootDir,
    routes: resolvedOptions.routes,
    sourceMapSourcePaths: resolvedOptions.sourceMapSourcePaths,
    sourceMaps: resolvedOptions.sourceMaps,
    targets: resolvedOptions.stylesTarget,
    watchIgnore: resolvedOptions.watchOptions?.ignore,
  })
  if (resolvedOptions.files.extensions.length > 0) {
    fileCompiler = createFileCompiler({
      cache: resolvedOptions.files.cache,
      cacheKey: resolvedOptions.files.cacheKey,
      extensions: resolvedOptions.files.extensions,
      fingerprintAssets: resolvedOptions.fingerprintAssets,
      globalTransforms: resolvedOptions.files.globalTransforms,
      isAllowed: accessPolicy.isAllowed,
      maxRequestTransforms: resolvedOptions.files.maxRequestTransforms,
      transforms: resolvedOptions.files.transforms,
      rootDir: resolvedOptions.rootDir,
      routes: resolvedOptions.routes,
    })
  }
  if (resolvedOptions.watchOptions) {
    watcher = createAssetServerWatcher({
      ...resolvedOptions.watchOptions,
      onChokidarWatcherCreated(createdWatcher) {
        chokidarWatcher = createdWatcher
      },
      onFileEvent: handleWatchEvent,
      rootDir: resolvedOptions.rootDir,
    })
    watcher.updateWatchedDirectories(
      { add: accessPolicy.getPackageWatchDirectories(), remove: [] },
      { includeAncestors: false },
    )
  }
  async function responseForError(error: unknown): Promise<Response> {
    try {
      return (await resolvedOptions.onError(error)) ?? internalServerError()
    } catch (error) {
      console.error(`There was an error in the asset server error handler: ${error}`)
      return internalServerError()
    }
  }

  async function handleWatchEvent(filePath: string, event: 'add' | 'change' | 'unlink') {
    scriptEntries.clear()
    try {
      let normalizedFilePath = normalizeFilePath(filePath)
      accessPolicy.handleFileEvent(normalizedFilePath)
      scriptCompiler.invalidateFileEvent(normalizedFilePath, event)
      styleCompiler.invalidateFileEvent(normalizedFilePath, event)
      await fileCompiler?.handleFileEvent(normalizedFilePath, event)
    } catch (error) {
      console.error(`There was an error invalidating the asset server cache: ${error}`)
    }
  }

  async function handleBrowserHmrFileEvents(
    events: readonly BrowserHmrFileEvent[],
  ): Promise<readonly BrowserHmrEvent[]> {
    if (events.length === 0) return []
    scriptEntries.clear()
    try {
      return await classifyBrowserHmrFileEvents(events)
    } finally {
      // Entries computed while events were processed may predate later invalidations or HMR
      // timestamps, so drop them once every event has been handled.
      scriptEntries.clear()
    }
  }

  async function classifyBrowserHmrFileEvents(
    events: readonly BrowserHmrFileEvent[],
  ): Promise<readonly BrowserHmrEvent[]> {
    let browserHmrEvents: BrowserHmrEvent[] = []

    for (let event of events) {
      let normalizedFilePath = normalizeFilePath(event.filePath)
      let scriptUpdates = await scriptCompiler.classifyHmrFileEvent(normalizedFilePath, event.event)
      let scriptPayload = await createScriptHmrPayloadWithImportMaps(scriptUpdates)
      if (scriptPayload) {
        browserHmrEvents.push(
          createBrowserHmrEvent(scriptPayload, getScriptHmrUpdateFiles(scriptUpdates), hmrDataKey),
        )
      }

      let styleUpdates = await styleCompiler.classifyHmrFileEvent(normalizedFilePath, event.event)
      for (let styleUpdate of styleUpdates) {
        browserHmrEvents.push(
          createBrowserHmrEvent(
            {
              timestamp: styleUpdate.timestamp,
              type: 'browser:update',
              updates: [
                {
                  path: styleUpdate.path,
                  type: 'css',
                },
              ],
            },
            [styleUpdate.filePath],
            hmrDataKey,
          ),
        )
      }

      await fileCompiler?.handleFileEvent(normalizedFilePath, event.event)
    }

    return browserHmrEvents

    async function createScriptHmrPayloadWithImportMaps(
      updates: ScriptHmrUpdate[],
    ): Promise<Extract<HmrPayload, { type: 'browser:reload' | 'browser:update' }> | null> {
      let payload = createScriptHmrPayload(updates)
      if (!payload || payload.type === 'browser:reload') return payload

      let acceptedUpdates = updates.filter((update) => update.accepted)
      let importMaps = await Promise.all(
        acceptedUpdates.map(async (update) => {
          try {
            return await scriptCompiler.getImportMap(update.acceptedFilePath)
          } catch (error) {
            if (!isAssetServerCompilationError(error)) throw error
            return undefined
          }
        }),
      )
      return {
        ...payload,
        updates: payload.updates.map((update, index) => ({
          ...update,
          ...(importMaps[index] ? { importMap: importMaps[index] } : null),
        })),
      }
    }
  }

  function updateBrowserHmrWatchedFiles(delta: BrowserHmrWatchedFileDelta): void {
    browserHmrChannelPromise
      .then((channel) => {
        channel?.updateWatchedFiles(delta)
      })
      .catch((error: unknown) => {
        console.error(`There was an error updating browser HMR watched files: ${error}`)
      })
  }

  let assetServer: AssetServer<transforms> = {
    getAssetDetails(input) {
      return assetInspector.getAssetDetails(input)
    },
    getAssets() {
      return assetInspector.getAssets()
    },
    async fetch(request) {
      if (request.method !== 'GET' && request.method !== 'HEAD') return null
      let requestPathname = new URL(request.url).pathname

      if (resolvedOptions.hmr) {
        if (requestPathname === hmrPathnames.client) {
          let browserHmrChannel = await browserHmrChannelPromise
          assertBrowserEventUrl(browserHmrChannel?.url)
          return await createHmrClientResponse(
            browserHmrChannel.url,
            hmrDataKey,
            resolvedOptions.hmrModuleImporter,
            request.method,
            scriptCompiler,
          )
        }
      }

      let requestUrl = new URL(request.url)
      let requestedTransform = normalizeRequestedTransformQuery(requestUrl.searchParams)
      let parsedRequestPathname = parseAssetRequestPathname(requestPathname, {
        fingerprintAssets: resolvedOptions.fingerprintAssets,
        routes: resolvedOptions.routes,
      })
      if (!parsedRequestPathname) return null

      try {
        let ifNoneMatch = request.headers.get('If-None-Match')

        if (isStyleFilePath(parsedRequestPathname.filePath)) {
          if (requestedTransform !== null) {
            return badRequest(
              'Asset request transforms are only supported for configured file assets',
            )
          }
          let styleResult = await styleCompiler.getStyle(parsedRequestPathname.filePath, {
            ifNoneMatch,
            isSourceMapRequest: parsedRequestPathname.isSourceMapRequest,
            requestedFingerprint: parsedRequestPathname.requestedFingerprint,
          })
          if (styleResult.type === 'not-modified') {
            return new Response(null, {
              status: 304,
              headers: { ETag: styleResult.etag },
            })
          }

          let compiledStyle = styleResult.style

          if (parsedRequestPathname.requestedFingerprint !== null) {
            let fingerprint = parsedRequestPathname.isSourceMapRequest
              ? compiledStyle.sourceMap?.fingerprint
              : compiledStyle.fingerprint
            if (fingerprint !== parsedRequestPathname.requestedFingerprint) return null
          }

          return createResponseForStyle(compiledStyle, {
            cacheControl: parsedRequestPathname.cacheControl,
            ifNoneMatch,
            isSourceMapRequest: parsedRequestPathname.isSourceMapRequest,
            method: request.method,
          })
        }

        if (!isScriptFilePath(parsedRequestPathname.filePath)) {
          if (!fileCompiler?.isServedFilePath(parsedRequestPathname.filePath)) {
            return null
          }
          if (parsedRequestPathname.isSourceMapRequest) {
            return null
          }

          let fileResult = await fileCompiler.getFile(parsedRequestPathname.filePath, {
            ifNoneMatch,
            requestedFingerprint: parsedRequestPathname.requestedFingerprint,
            transform: requestedTransform,
          })
          if (fileResult.type === 'not-modified') {
            return new Response(null, {
              status: 304,
              headers: { ETag: fileResult.etag },
            })
          }

          if (parsedRequestPathname.requestedFingerprint !== null) {
            if (fileResult.file.fingerprint !== parsedRequestPathname.requestedFingerprint) {
              return null
            }
          }

          return createResponseForFile(fileResult.file, {
            cacheControl: parsedRequestPathname.cacheControl,
            ifNoneMatch,
            method: request.method,
          })
        }

        if (requestedTransform !== null) {
          return badRequest(
            'Asset request transforms are only supported for configured file assets',
          )
        }
        let scriptResult = await scriptCompiler.getScript(parsedRequestPathname.filePath, {
          ifNoneMatch,
          isSourceMapRequest: parsedRequestPathname.isSourceMapRequest,
          requestedFingerprint: parsedRequestPathname.requestedFingerprint,
        })
        if (scriptResult.type === 'not-modified') {
          return new Response(null, {
            status: 304,
            headers: { ETag: scriptResult.etag },
          })
        }

        let compiledScript = scriptResult.script

        if (parsedRequestPathname.requestedFingerprint !== null) {
          let fingerprint = parsedRequestPathname.isSourceMapRequest
            ? compiledScript.sourceMap?.fingerprint
            : compiledScript.fingerprint
          if (fingerprint !== parsedRequestPathname.requestedFingerprint) return null
        }

        return createResponseForScript(compiledScript, {
          cacheControl: parsedRequestPathname.cacheControl,
          ifNoneMatch,
          isSourceMapRequest: parsedRequestPathname.isSourceMapRequest,
          method: request.method,
        })
      } catch (error) {
        // A direct request can race with the filesystem or fail a deeper allowFiles check while
        // compiling imports. In this fetch context, both cases should fall through as "not
        // handled here" so the outer router can continue to its own 404 behavior.
        if (
          isAssetServerCompilationError(error) &&
          (error.code === 'FILE_NOT_FOUND' || error.code === 'FILE_NOT_ALLOWED')
        ) {
          return null
        }
        if (isAssetServerCompilationError(error) && error.code === 'FILE_TRANSFORM_QUERY_INVALID') {
          return new Response(error.message, {
            status: 400,
            headers: { 'Content-Type': 'text/plain; charset=utf-8' },
          })
        }

        return responseForError(error)
      }
    },

    async getHref(filePath, hrefOptions) {
      let transform = getHrefTransform(hrefOptions, resolvedOptions.files)
      let typeCheckFilePath = stripFilePathUrlSuffix(filePath)

      if (isStyleFilePath(typeCheckFilePath)) {
        if (transform !== null) {
          throw new TypeError(
            'assetServer.getHref() only supports transforms for configured file assets',
          )
        }
        return styleCompiler.getHref(filePath)
      }

      if (fileCompiler?.isServedFilePath(typeCheckFilePath)) {
        return fileCompiler.getHref(filePath, {
          transform,
        })
      }

      if (!isScriptFilePath(typeCheckFilePath)) {
        throw createAssetServerCompilationError(`File type is not supported: ${filePath}`, {
          code: 'FILE_NOT_SUPPORTED',
        })
      }

      if (transform !== null) {
        throw new TypeError(
          'assetServer.getHref() only supports transforms for configured file assets',
        )
      }

      return scriptCompiler.getHref(filePath)
    },
    async getScriptEntry(filePath) {
      let entry = scriptEntries.get(filePath)
      if (!entry) {
        entry = Promise.all([
          assetServer.getHref(filePath),
          assetServer.getPreloads(filePath),
          assetServer.getImportMap(filePath),
        ]).then(([href, preloads, importMap]) => ({ href, preloads, importMap }))
        scriptEntries.set(filePath, entry)
        void entry.catch(() => {
          if (scriptEntries.get(filePath) === entry) scriptEntries.delete(filePath)
        })
      }

      return structuredClone(await entry)
    },
    async getPreloads(filePath) {
      let filePaths = Array.isArray(filePath) ? filePath : [filePath]
      let fileAssetFiles: string[] = []
      let styleFiles: string[] = []
      let scriptFiles: string[] = []
      let groupedAssetTypes: ('script' | 'style' | 'file')[] = []

      for (let nextFilePath of filePaths) {
        let typeCheckFilePath = stripFilePathUrlSuffix(nextFilePath)

        if (isStyleFilePath(typeCheckFilePath)) {
          if (!groupedAssetTypes.includes('style')) {
            groupedAssetTypes.push('style')
          }
          styleFiles.push(nextFilePath)
          continue
        }

        if (fileCompiler?.isServedFilePath(typeCheckFilePath)) {
          if (!groupedAssetTypes.includes('file')) {
            groupedAssetTypes.push('file')
          }
          fileAssetFiles.push(nextFilePath)
          continue
        }

        if (!groupedAssetTypes.includes('script')) {
          groupedAssetTypes.push('script')
        }
        scriptFiles.push(nextFilePath)
      }

      if (styleFiles.length === 0 && scriptFiles.length === 0 && fileAssetFiles.length === 0) {
        return []
      }

      if (styleFiles.length === 0 && fileAssetFiles.length === 0) {
        return flattenPreloadLayers(await scriptCompiler.getPreloadLayers(filePath))
      }

      if (scriptFiles.length === 0 && fileAssetFiles.length === 0) {
        return flattenPreloadLayers(await styleCompiler.getPreloadLayers(filePath))
      }

      if (scriptFiles.length === 0 && styleFiles.length === 0) {
        return flattenPreloadLayers(await getFilePreloadLayers(fileCompiler, fileAssetFiles))
      }

      // Mixed asset type preloads need to be merged, so we merge in order of first asset type seen.
      let preloadLayerGroupPromises = groupedAssetTypes.flatMap((assetType) => {
        switch (assetType) {
          case 'script':
            return scriptFiles.length > 0 ? [scriptCompiler.getPreloadLayers(scriptFiles)] : []
          case 'style':
            return styleFiles.length > 0 ? [styleCompiler.getPreloadLayers(styleFiles)] : []
          case 'file':
            return fileAssetFiles.length > 0
              ? [getFilePreloadLayers(fileCompiler, fileAssetFiles)]
              : []
        }
      })

      return mergePreloadLayers(await Promise.all(preloadLayerGroupPromises))
    },
    async getImportMap(filePath) {
      let filePaths = Array.isArray(filePath) ? [...filePath] : [filePath]
      for (let nextFilePath of filePaths) {
        let typeCheckFilePath = stripFilePathUrlSuffix(nextFilePath)
        if (!isScriptFilePath(typeCheckFilePath)) {
          throw new TypeError(
            `assetServer.getImportMap() only supports script files: ${nextFilePath}`,
          )
        }
      }

      if (resolvedOptions.hmrModuleImporter) {
        let moduleImporter = await scriptCompiler.resolveSpecifierFromRoot(
          resolvedOptions.hmrModuleImporter,
        )
        filePaths.push(moduleImporter.identityPath)
      }

      return scriptCompiler.getImportMap(filePaths)
    },
    async close() {
      if (closed) return
      closed = true
      let unsubscribe = unsubscribeBrowserHmrFileEvents
      unsubscribeBrowserHmrFileEvents = undefined
      unsubscribe?.()
      try {
        let channel = await browserHmrChannelPromise
        channel?.close()
      } finally {
        await watcher?.close()
      }
    },
  }

  if (chokidarWatcher) {
    chokidarWatcherByAssetServer.set(assetServer, chokidarWatcher)
  }
  if (watcher) {
    watcherByAssetServer.set(assetServer, watcher)
  }

  return assetServer
}

function getHrefTransform<transforms extends AssetRequestTransformMap>(
  options: AssetServerGetHrefOptions<transforms> | undefined,
  files: ResolvedAssetServerFilesOptions,
): readonly string[] | null {
  if (!options) return null
  let transform = options.transform
  if (transform.length === 0) {
    return null
  }

  return serializeAssetTransformInvocations(transform, files.transforms, files.maxRequestTransforms)
}

function normalizeRequestedTransformQuery(searchParams: URLSearchParams): readonly string[] | null {
  let transforms = searchParams.getAll('transform')
  return transforms.length > 0 ? transforms : null
}

function internalServerError(): Response {
  return new Response('Internal Server Error', {
    status: 500,
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  })
}

function badRequest(message: string): Response {
  return new Response(message, {
    status: 400,
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  })
}

function getHmrPathnames(basePath: string): { client: string; events: string } {
  let hmrBase = `${basePath}/__remix_hmr`
  return {
    client: `${hmrBase}/client.js`,
    events: `${hmrBase}/events`,
  }
}

async function createHmrClientResponse(
  eventPathname: string,
  dataKey: string,
  moduleImporter: string | null,
  method: string,
  scriptCompiler: ReturnType<typeof createScriptCompiler>,
): Promise<Response> {
  let moduleImporterHref = moduleImporter
    ? (await scriptCompiler.resolveSpecifierFromRoot(moduleImporter)).href
    : null
  return new Response(
    method === 'HEAD'
      ? null
      : createHmrClientSource({ dataKey, eventPathname, moduleImporter: moduleImporterHref }),
    {
      headers: {
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/javascript; charset=utf-8',
      },
    },
  )
}

function assertBrowserEventUrl(url: string | undefined): asserts url is string {
  if (url === undefined) {
    throw new TypeError('hmr must be provided')
  }
}

function createHmrPayloadSender(): (payload: HmrPayload) => void {
  return () => {}
}

function createBrowserHmrEvent(
  payload: Extract<HmrPayload, { type: 'browser:reload' | 'browser:update' }>,
  files: readonly string[],
  dataKey: string,
): BrowserHmrEvent {
  if (payload.type === 'browser:reload') {
    return {
      ...(files.length === 0 ? {} : { files: [...files] }),
      type: 'reload',
    }
  }

  return {
    data: {
      [dataKey]: {
        timestamp: payload.timestamp,
        updates: payload.updates,
      },
    },
    ...(files.length === 0 ? {} : { files: [...files] }),
    type: 'update',
  }
}

function getScriptHmrUpdateFiles(updates: ScriptHmrUpdate[]): string[] {
  return [...new Set(updates.map((update) => update.filePath))]
}

export function createScriptHmrPayload(
  updates: ScriptHmrUpdate[],
): Extract<HmrPayload, { type: 'browser:reload' | 'browser:update' }> | null {
  let timestamp = updates[0]?.timestamp ?? Date.now()
  let rejectedUpdate = updates.find((update) => !update.accepted)
  if (rejectedUpdate) {
    return {
      type: 'browser:reload',
    }
  }

  let acceptedUpdates = updates.filter((update) => update.accepted)
  if (acceptedUpdates.length === 0) return null

  return {
    timestamp,
    type: 'browser:update',
    updates: acceptedUpdates.map((update) => ({
      ...(update.acceptedUrlPathname === update.path
        ? {}
        : { acceptedPath: update.acceptedUrlPathname }),
      path: update.path,
      type: 'js',
    })),
  }
}

function mergePreloadLayers(preloadLayersByRoot: readonly (readonly string[][])[]): string[] {
  let urls: string[] = []
  let seen = new Set<string>()
  let maxDepth = Math.max(0, ...preloadLayersByRoot.map((layers) => layers.length))

  for (let depth = 0; depth < maxDepth; depth++) {
    for (let preloadLayers of preloadLayersByRoot) {
      for (let url of preloadLayers[depth] ?? []) {
        if (seen.has(url)) continue
        seen.add(url)
        urls.push(url)
      }
    }
  }

  return urls
}

function flattenPreloadLayers(preloadLayers: readonly (readonly string[])[]): string[] {
  return preloadLayers.flatMap((layer) => layer)
}

async function getFilePreloadLayers<transforms extends AssetRequestTransformMap>(
  fileCompiler: FileCompiler | null,
  filePaths: readonly string[],
): Promise<string[][]> {
  if (filePaths.length === 0) {
    return []
  }

  if (!fileCompiler) {
    throw createAssetServerCompilationError('File type is not supported', {
      code: 'FILE_NOT_SUPPORTED',
    })
  }

  return [
    await Promise.all(
      filePaths.map((filePath) =>
        fileCompiler.getHref(filePath, {
          transform: null,
        }),
      ),
    ),
  ]
}

function defaultErrorHandler(error: unknown): void {
  console.error(error)
}

function resolveAssetServerOptions<transforms extends AssetRequestTransformMap>(
  options: AssetServerCreateOptions<transforms>,
): ResolvedAssetServerOptions<transforms> {
  let rootDir = normalizeFilePath(fs.realpathSync(path.resolve(options.rootDir ?? process.cwd())))
  let basePath = normalizeBasePath(options.basePath)
  let scriptOptions = options.scripts ?? {}
  let fingerprintAssets = normalizeFingerprintOptions({
    fingerprint: options.fingerprint,
    watch: options.watch,
  })
  let watchOptions = normalizeWatchOptions(options.watch)
  let hmr = normalizeHmrOptions(options.hmr)
  let mounts = options.mounts ?? defaultMounts

  if (hmr.channel && watchOptions === null) {
    throw new TypeError('hmr requires watch mode')
  }
  if (Object.keys(mounts).length === 0) {
    throw new TypeError('mounts must include at least one entry')
  }
  return {
    allowFiles: options.allowFiles,
    allowPackages: options.allowPackages,
    basePath,
    define: scriptOptions.define,
    denyFiles: options.denyFiles,
    external: scriptOptions.external ?? [],
    files: normalizeFilesOptions(options.files),
    fingerprintAssets,
    hmr: hmr.channel,
    hmrModuleImporter: hmr.moduleImporter,
    minify: options.minify ?? false,
    mounts,
    loaders: scriptOptions.loaders ?? [],
    onError: options.onError ?? defaultErrorHandler,
    rootDir,
    routes: compileRoutes(basePath, [
      {
        mounts,
        rootDir,
      },
      ...getInjectedPackageMountConfigs(),
      ...getVirtualStoreMountConfigs({ mounts, rootDir }),
    ]),
    sourceMapSourcePaths: options.sourceMapSourcePaths ?? 'url',
    sourceMaps: options.sourceMaps,
    scriptsTarget: resolveScriptTarget(options.target),
    stylesTarget: resolveStyleTarget(options.target),
    watchOptions,
  }
}

function normalizeHmrOptions(options: AssetServerOptions['hmr']): {
  channel: BrowserHmrChannelFactory | null
  moduleImporter: string | null
} {
  if (options === undefined) return { channel: null, moduleImporter: null }
  if (typeof options === 'function') return { channel: options, moduleImporter: null }
  if (!options || typeof options !== 'object' || typeof options.channel !== 'function') {
    throw new TypeError('hmr must be a function or an object with a channel function')
  }
  if (
    options.moduleImporter !== undefined &&
    (typeof options.moduleImporter !== 'string' || options.moduleImporter.trim().length === 0)
  ) {
    throw new TypeError('hmr.moduleImporter must be a non-empty string')
  }
  return { channel: options.channel, moduleImporter: options.moduleImporter ?? null }
}

function createBrowserHmrChannel(
  createChannel: BrowserHmrChannelFactory | null,
  handleFileEvents: BrowserHmrFileEventHandler,
  isClosed: () => boolean,
  setUnsubscribe: (unsubscribe: () => void) => void,
): Promise<BrowserHmrChannel | null> {
  if (!createChannel) return Promise.resolve(null)

  let channelOrPromise: BrowserHmrChannel | undefined | Promise<BrowserHmrChannel | undefined>
  try {
    channelOrPromise = createChannel()
  } catch (error) {
    return Promise.reject(error)
  }

  return Promise.resolve(channelOrPromise).then((channel) => {
    if (channel === undefined) return null
    validateBrowserHmrChannel(channel)

    if (isClosed()) {
      channel.close()
      return null
    }

    setUnsubscribe(channel.onFileEvents(handleFileEvents))
    return channel
  })
}

function validateBrowserHmrChannel(channel: unknown): asserts channel is BrowserHmrChannel {
  if (channel === null || typeof channel !== 'object') {
    throw new TypeError('hmr must create an object')
  }
  if (!('url' in channel) || typeof channel.url !== 'string') {
    throw new TypeError('hmr must create a channel with a string url')
  }
  if (!('close' in channel) || typeof channel.close !== 'function') {
    throw new TypeError('hmr must create a channel with a close function')
  }
  if (!('onFileEvents' in channel) || typeof channel.onFileEvents !== 'function') {
    throw new TypeError('hmr must create a channel with an onFileEvents function')
  }
  if (!('updateWatchedFiles' in channel) || typeof channel.updateWatchedFiles !== 'function') {
    throw new TypeError('hmr must create a channel with an updateWatchedFiles function')
  }
}

function normalizeBasePath(basePath: string): string {
  if (typeof basePath !== 'string') {
    throw new TypeError('basePath must be a string')
  }

  return normalizePathname(basePath || '/').replace(/\/+$/, '') || '/'
}

function normalizeFingerprintOptions(options: {
  fingerprint: AssetServerOptions['fingerprint']
  watch: AssetServerOptions['watch']
}): boolean {
  if (options.fingerprint !== undefined && typeof options.fingerprint !== 'boolean') {
    throw new TypeError('fingerprint must be a boolean')
  }

  if (!options.fingerprint) {
    return false
  }

  if (options.watch !== false) {
    throw new TypeError('fingerprint cannot be used with watch mode')
  }

  return true
}

function normalizeWatchOptions(
  options: AssetServerOptions['watch'],
): AssetServerWatchOptions | null {
  if (options === false) return null
  if (options == null || options === true) return {}
  return options
}

function hasPackages(packages: readonly string[] | undefined): boolean {
  return packages !== undefined && packages.length > 0
}

function getPackageSearchRoots(
  mounts: Readonly<Record<string, string>>,
  rootDir: string,
): readonly string[] {
  return Object.values(mounts).map((fileRoot) => path.resolve(rootDir, fileRoot))
}

function parseAssetRequestPathname(
  pathname: string,
  options: {
    fingerprintAssets: boolean
    routes: CompiledRoutes
  },
): {
  cacheControl: string
  filePath: string
  isSourceMapRequest: boolean
  requestedFingerprint: string | null
} | null {
  let isSourceMapRequest = pathname.endsWith('.map')
  let pathWithoutMap = isSourceMapRequest ? pathname.slice(0, -4) : pathname
  let fingerprint = parseFingerprintSuffix(pathWithoutMap)
  let filePath = options.routes.resolveUrlPathname(fingerprint.pathname)
  if (!filePath) return null
  if (options.fingerprintAssets && fingerprint.requestedFingerprint === null) return null

  return {
    cacheControl: getFingerprintRequestCacheControl(fingerprint.requestedFingerprint),
    filePath,
    isSourceMapRequest,
    requestedFingerprint: fingerprint.requestedFingerprint,
  }
}

function isScriptFilePath(filePath: string): boolean {
  return scriptExtensionSet.has(path.extname(filePath).toLowerCase())
}

function stripFilePathUrlSuffix(filePath: string): string {
  if (filePath.startsWith('file://')) {
    return new URL(filePath).pathname
  }

  let queryIndex = filePath.indexOf('?')
  return queryIndex === -1 ? filePath : filePath.slice(0, queryIndex)
}
