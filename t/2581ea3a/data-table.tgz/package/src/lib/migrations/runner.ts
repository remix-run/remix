import type { DatabaseDriver, TransactionToken } from '../driver.ts'
import type {
  MigrationOperationOptions,
  MigrateResult,
  MigrationDescriptor,
  MigrationDirection,
  MigrationJournalRow,
  MigrationRegistry,
  MigrationStatus,
  MigrationStatusEntry,
  MigrationTransactionMode,
} from '../migrations.ts'

interface MigrationRunnerOptions {
  journalTable?: string
}

interface MigrationRunner {
  up(options?: MigrationOperationOptions): Promise<MigrateResult>
  down(options?: MigrationOperationOptions): Promise<MigrateResult>
  status(): Promise<MigrationStatusEntry[]>
}

import { parseTransactionDirective } from './directive.ts'
import {
  deleteJournalRow,
  ensureMigrationJournal,
  getBatch,
  hasMigrationJournal,
  insertJournalRow,
  loadJournalRows,
  computeChecksum,
} from './journal-store.ts'
import { resolveMigrations } from './registry.ts'

type MigrationRunnerContext = DatabaseDriver

type RunMigrationsInput = {
  driver: MigrationRunnerContext
  migrations: MigrationDescriptor[]
  journalTable: string
  direction: MigrationDirection
  options: MigrationOperationOptions
}

function assertStepOption(step: number | undefined): void {
  if (step === undefined) {
    return
  }

  if (!Number.isInteger(step) || step < 1) {
    throw new Error('Invalid migration step option. Expected a positive integer.')
  }
}

function assertMigrationOperationOptions(options: MigrationOperationOptions): void {
  if (options.to !== undefined && options.step !== undefined) {
    throw new Error('Cannot combine "to" and "step" migration options in the same run')
  }
}

function resolveTargetOption(
  migrations: MigrationDescriptor[],
  to: string | undefined,
): string | undefined {
  if (to === undefined) {
    return undefined
  }

  // Accept either a bare migration id or the full `id_name` directory form and
  // normalize to the bare id so range filtering compares ids consistently.
  let matches = migrations.filter(
    (migration) => migration.id === to || migration.id + '_' + migration.name === to,
  )

  if (matches.length === 0) {
    throw new Error('Unknown migration target: ' + to)
  }

  if (matches.length > 1) {
    throw new Error(
      'Ambiguous migration target "' +
        to +
        '". Matches: ' +
        matches.map((migration) => migration.id + '_' + migration.name).join(', '),
    )
  }

  return matches[0].id
}

async function assertMigrationIntegrity(
  migrations: MigrationDescriptor[],
  journal: MigrationJournalRow[],
  direction: MigrationDirection,
): Promise<void> {
  let migrationMap = new Map(migrations.map((migration) => [migration.id, migration]))

  for (let row of journal) {
    let migration = migrationMap.get(row.id)

    if (!migration) {
      // Rolling back must stay possible when journal rows have no matching
      // migration files, so only forward runs hard-error on orphaned entries.
      if (direction === 'down') {
        continue
      }

      throw new Error(
        'Applied migration "' + row.id + '_' + row.name + '" is missing from current migrations',
      )
    }

    let expected = await computeChecksum(migration)

    if (expected !== row.checksum) {
      throw new Error(
        'Migration checksum drift detected for "' +
          row.id +
          '" (journal=' +
          row.checksum +
          ', current=' +
          expected +
          ')',
      )
    }
  }
}

function resolveTransactionMode(migration: MigrationDescriptor): MigrationTransactionMode {
  if (migration.transaction) {
    return migration.transaction
  }

  let directive = parseTransactionDirective(migration.up)

  if (directive) {
    return directive
  }

  return 'auto'
}

async function runMigrations(input: RunMigrationsInput): Promise<MigrateResult> {
  if (input.driver.capabilities.migrationLock && !input.driver.withMigrationLock) {
    throw new Error(
      'Database driver reports migration lock support but does not implement withMigrationLock()',
    )
  }

  if (input.driver.withMigrationLock) {
    return input.driver.withMigrationLock(input.journalTable, (driver) =>
      runMigrationsUnlocked({ ...input, driver }),
    )
  }

  return runMigrationsUnlocked(input)
}

async function runMigrationsUnlocked(input: RunMigrationsInput): Promise<MigrateResult> {
  let driver = input.driver
  let migrations = input.migrations
  let journalTable = input.journalTable
  let dryRun = Boolean(input.options.dryRun)
  let step = input.options.step

  assertMigrationOperationOptions(input.options)
  assertStepOption(step)

  let target = resolveTargetOption(migrations, input.options.to)

  let sql: string[] = []

  let journal: MigrationJournalRow[] = []

  if (dryRun) {
    let canReadJournal = await hasMigrationJournal(driver, journalTable)

    if (canReadJournal) {
      journal = await loadJournalRows(driver, journalTable)
    }
  } else {
    await ensureMigrationJournal(driver, journalTable)
    journal = await loadJournalRows(driver, journalTable)
  }

  let appliedMap = new Map(journal.map((row) => [row.id, row]))
  await assertMigrationIntegrity(migrations, journal, input.direction)
  let toRun: MigrationDescriptor[] = []

  if (input.direction === 'up') {
    for (let migration of migrations) {
      if (!appliedMap.has(migration.id)) {
        toRun.push(migration)
      }
    }

    if (target) {
      toRun = toRun.filter((migration) => migration.id <= target)
    }

    if (step !== undefined) {
      toRun = toRun.slice(0, step)
    }
  } else {
    toRun = migrations.filter((migration) => appliedMap.has(migration.id)).reverse()

    if (target) {
      toRun = toRun.filter((migration) => migration.id >= target)
    }

    if (step !== undefined) {
      toRun = toRun.slice(0, step)
    }

    for (let migration of toRun) {
      if (migration.down === undefined) {
        throw new Error('Migration "' + migration.id + '" has no down script')
      }
    }
  }

  let applied: MigrationStatusEntry[] = []
  let reverted: MigrationStatusEntry[] = []
  let batch = getBatch(journal)

  for (let migration of toRun) {
    let script = (input.direction === 'up' ? migration.up : migration.down) as string
    let mode = resolveTransactionMode(migration)

    if (mode === 'required' && !driver.capabilities.transactionalDdl) {
      throw new Error(
        'Migration "' +
          migration.id +
          '" requires transactional DDL, but the database does not support it',
      )
    }

    let shouldUseTransaction = !dryRun && mode !== 'none' && driver.capabilities.transactionalDdl
    let token: TransactionToken | undefined

    if (shouldUseTransaction) {
      token = await driver.beginTransaction()
    }

    sql.push(script)

    try {
      if (!dryRun) {
        if (script.trim().length > 0) {
          await driver.executeScript(script, token)
        }
      }

      if (input.direction === 'up') {
        if (!dryRun) {
          await insertJournalRow(
            driver,
            journalTable,
            {
              id: migration.id,
              name: migration.name,
              checksum: await computeChecksum(migration),
              batch,
            },
            token,
          )
        }

        applied.push({
          id: migration.id,
          name: migration.name,
          status: 'applied',
        })
      } else {
        if (!dryRun) {
          await deleteJournalRow(driver, journalTable, migration.id, token)
        }

        reverted.push({
          id: migration.id,
          name: migration.name,
          status: 'pending',
        })
      }
    } catch (error) {
      if (token) {
        try {
          await driver.rollbackTransaction(token)
        } catch (rollbackError) {
          throw new AggregateError([error, rollbackError], 'Migration and rollback both failed', {
            cause: error,
          })
        }
      }

      throw error
    }

    if (token) {
      await driver.commitTransaction(token)
    }
  }

  return {
    applied,
    reverted,
    sql,
  }
}

export function createMigrationRunner(
  driver: DatabaseDriver,
  migrations: MigrationDescriptor[] | MigrationRegistry,
  options: MigrationRunnerOptions = {},
): MigrationRunner {
  let journalTable = options.journalTable ?? 'data_table_migrations'

  return {
    async up(runOptions: MigrationOperationOptions = {}): Promise<MigrateResult> {
      return runMigrations({
        driver,
        migrations: resolveMigrations(migrations),
        journalTable,
        direction: 'up',
        options: runOptions,
      })
    },
    async down(runOptions: MigrationOperationOptions = {}): Promise<MigrateResult> {
      return runMigrations({
        driver,
        migrations: resolveMigrations(migrations),
        journalTable,
        direction: 'down',
        options: runOptions,
      })
    },
    async status(): Promise<MigrationStatusEntry[]> {
      let journal = (await hasMigrationJournal(driver, journalTable))
        ? await loadJournalRows(driver, journalTable)
        : []
      let journalMap = new Map(journal.map((row) => [row.id, row]))
      let sortedMigrations = resolveMigrations(migrations)
      let migrationIds = new Set(sortedMigrations.map((migration) => migration.id))

      let statuses: MigrationStatusEntry[] = []

      for (let migration of sortedMigrations) {
        let journalRow = journalMap.get(migration.id)

        if (!journalRow) {
          statuses.push({
            id: migration.id,
            name: migration.name,
            status: 'pending' as MigrationStatus,
          })
          continue
        }

        let checksum = await computeChecksum(migration)

        statuses.push({
          id: migration.id,
          name: migration.name,
          status:
            checksum === journalRow.checksum
              ? ('applied' as MigrationStatus)
              : ('drifted' as MigrationStatus),
          appliedAt: journalRow.appliedAt,
          batch: journalRow.batch,
          checksum: journalRow.checksum,
        })
      }

      for (let journalRow of journal) {
        if (migrationIds.has(journalRow.id)) {
          continue
        }

        statuses.push({
          id: journalRow.id,
          name: journalRow.name,
          status: 'missing',
          appliedAt: journalRow.appliedAt,
          batch: journalRow.batch,
          checksum: journalRow.checksum,
        })
      }

      return statuses.sort((left, right) => left.id.localeCompare(right.id))
    },
  }
}
