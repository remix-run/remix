/**
 * Base error for all `data-table` failures.
 */
export class DataTableError extends Error {
  /**
   * Stable error code identifying the failure category.
   */
  code: string

  /**
   * Optional structured metadata attached to the failure.
   */
  metadata?: Record<string, unknown>

  constructor(
    message: string,
    options?: {
      code?: string
      cause?: unknown
      metadata?: Record<string, unknown>
    },
  ) {
    super(message, { cause: options?.cause })
    this.name = 'DataTableError'
    this.code = options?.code ?? 'DATA_TABLE_ERROR'
    this.metadata = options?.metadata
  }
}

/**
 * Thrown when input data fails schema validation.
 */
export class DataTableValidationError extends DataTableError {
  /**
   * Validation issues reported by the schema validator.
   */
  issues: ReadonlyArray<unknown>

  constructor(
    message: string,
    issues: ReadonlyArray<unknown>,
    options?: {
      cause?: unknown
      metadata?: Record<string, unknown>
    },
  ) {
    super(message, {
      code: 'DATA_TABLE_VALIDATION_ERROR',
      cause: options?.cause,
      metadata: options?.metadata,
    })

    this.name = 'DataTableValidationError'
    this.issues = issues
  }
}

/**
 * Thrown when a query is invalid for the current builder state.
 */
export class DataTableQueryError extends DataTableError {
  constructor(
    message: string,
    options?: {
      cause?: unknown
      metadata?: Record<string, unknown>
    },
  ) {
    super(message, {
      code: 'DATA_TABLE_QUERY_ERROR',
      cause: options?.cause,
      metadata: options?.metadata,
    })

    this.name = 'DataTableQueryError'
  }
}

/**
 * Thrown when database execution fails.
 */
export class DataTableDatabaseError extends DataTableError {
  constructor(
    message: string,
    options?: {
      cause?: unknown
      metadata?: Record<string, unknown>
    },
  ) {
    super(message, {
      code: 'DATA_TABLE_DATABASE_ERROR',
      cause: options?.cause,
      metadata: options?.metadata,
    })

    this.name = 'DataTableDatabaseError'
  }
}

/**
 * Thrown when a database constraint is violated.
 */
export class DataTableConstraintError extends DataTableError {
  constructor(
    message: string,
    options?: {
      cause?: unknown
      metadata?: Record<string, unknown>
    },
  ) {
    super(message, {
      code: 'DATA_TABLE_CONSTRAINT_ERROR',
      cause: options?.cause,
      metadata: options?.metadata,
    })

    this.name = 'DataTableConstraintError'
  }
}
